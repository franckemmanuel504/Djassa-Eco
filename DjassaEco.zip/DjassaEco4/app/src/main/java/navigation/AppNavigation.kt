package com.djassaeco.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.edit
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.djassaeco.data.FirestoreService
import com.djassaeco.data.model.*
import com.djassaeco.ui.components.DjassaBottomNavBar
import com.djassaeco.ui.screens.auth.*
import com.djassaeco.ui.screens.home.*
import com.djassaeco.ui.screens.dons.*
import com.djassaeco.ui.screens.publish.*
import com.djassaeco.ui.screens.chat.*
import com.djassaeco.ui.screens.detail.*
import com.djassaeco.ui.screens.checkout.*
import com.djassaeco.ui.screens.profile.*
import com.djassaeco.ui.screens.notifications.NotificationScreen
import com.djassaeco.ui.screens.TextileWasteScreen
import com.djassaeco.ui.viewmodels.MainViewModel
import com.djassaeco.ui.theme.EcoGreen
import com.google.firebase.auth.FirebaseAuth
import org.osmdroid.util.GeoPoint

private const val PREFS_NAME = "djassa_prefs"
private const val KEY_ONBOARDING_DONE = "onboarding_done"

@Composable
fun AppNavigation(navController: NavHostController) {
    val mainViewModel: MainViewModel = viewModel()
    val context = LocalContext.current
    val firestoreService = remember { FirestoreService() }

    // Écran de chargement pour éviter l'écran noir pendant l'initialisation
    if (mainViewModel.isLoading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = EcoGreen)
        }
        return
    }

    val currentBackStack by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStack?.destination?.route

    val showBottomBar = bottomNavList.any { currentRoute == it }
    
    // État partagé pour la livraison
    var pendingDeliveryResult by remember { mutableStateOf<DeliveryResult?>(null) }

    val prefs = remember { context.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE) }
    val onboardingDone = remember { prefs.getBoolean(KEY_ONBOARDING_DONE, false) }
    val currentUser = remember { FirebaseAuth.getInstance().currentUser }

    val startDestination = when {
        currentUser != null -> Screen.Home.route
        onboardingDone -> Screen.Login.route
        else -> Screen.Onboarding1.route
    }
    
    val completeOnboarding = {
        prefs.edit { putBoolean(KEY_ONBOARDING_DONE, true) }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                Surface(
                    tonalElevation = 8.dp,
                    modifier = Modifier.navigationBarsPadding() 
                ) {
                    DjassaBottomNavBar(
                        currentRoute = currentRoute,
                        navController = navController
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = startDestination,
            modifier         = Modifier.padding(innerPadding)
        ) {
            // AUTH
            composable(Screen.Onboarding1.route) {
                OnboardingScreen(page = 1, onNext = { navController.navigate(Screen.Onboarding2.route) }, onSkip = { completeOnboarding(); navController.navigate(Screen.Login.route) { popUpTo(0) } })
            }
            composable(Screen.Onboarding2.route) {
                OnboardingScreen(page = 2, onNext = { navController.navigate(Screen.Onboarding3.route) }, onSkip = { completeOnboarding(); navController.navigate(Screen.Login.route) { popUpTo(0) } })
            }
            composable(Screen.Onboarding3.route) {
                OnboardingScreen(page = 3, onNext = { completeOnboarding(); navController.navigate(Screen.Login.route) { popUpTo(0) } }, onSkip = null)
            }
            
            composable(Screen.Login.route) {
                LoginScreen(onLoginSuccess = { navController.navigate(Screen.Home.route) { popUpTo(0) } }, onRegisterSuccess = { navController.navigate(Screen.Home.route) { popUpTo(0) } })
            }
            
            composable(
                route = Screen.Otp.route,
                arguments = listOf(navArgument("verificationId") { type = NavType.StringType })
            ) { backStack ->
                val vId = backStack.arguments?.getString("verificationId") ?: ""
                OtpScreen(verificationIdFromNav = vId, onConfirmed = { navController.navigate(Screen.Home.route) { popUpTo(0) } })
            }

            // HOME
            composable(Screen.Home.route) {
                HomeScreen(
                    articles = mainViewModel.articles,
                    favoriIds = mainViewModel.favoriIds,
                    nonLuesCount = mainViewModel.nonLuesCount,
                    onToggleFavorite = { mainViewModel.toggleFavorite(it) },
                    onArticleClick  = { id -> 
                        val art = mainViewModel.articles.find { it.id == id }
                        if (art?.categorie == Categorie.DECHETS_TEXTILES) navController.navigate(Screen.TextileWaste.route)
                        else navController.navigate(Screen.Detail.createRoute(id))
                    },
                    onMsgClick      = { navController.navigate(Screen.Messages.route) },
                    onNotifClick    = { navController.navigate(Screen.Notifications.route) },
                    onProfileClick  = { navController.navigate(Screen.Profile.route) }
                )
            }

            composable(Screen.TextileWaste.route) {
                TextileWasteScreen(
                    articles = mainViewModel.articles.filter { it.categorie == Categorie.DECHETS_TEXTILES },
                    onBack = { navController.popBackStack() },
                    onArticleClick = { id -> navController.navigate(Screen.Detail.createRoute(id)) },
                    onContactClick = { article ->
                        mainViewModel.demarrerDiscussion(article) { convId ->
                            if (convId != null) navController.navigate(Screen.Chat.createRoute(convId))
                        }
                    }
                )
            }

            // MESSAGES
            composable(Screen.Messages.route) {
                MessagesScreen(
                    conversations = mainViewModel.conversations, 
                    onConvClick = { id -> navController.navigate(Screen.Chat.createRoute(id)) }
                )
            }
            
            composable(
                route = Screen.Chat.route,
                arguments = listOf(navArgument("convId") { type = NavType.StringType }),
                deepLinks = listOf(navDeepLink { uriPattern = "djassa://chat/{convId}" })
            ) { backStack ->
                val id = backStack.arguments?.getString("convId") ?: ""
                ChatScreen(
                    conversationId = id,
                    onBack = { navController.popBackStack() },
                    onNego = { itemId -> navController.navigate(Screen.Nego.createRoute(itemId)) },
                    onBuy = { itemId -> navController.navigate(Screen.Checkout.createRoute(itemId)) }
                )
            }

            // NOTIFICATIONS
            composable(Screen.Notifications.route) {
                NotificationScreen(
                    notifications = mainViewModel.notifications,
                    onBack = { navController.popBackStack() },
                    onToutMarquerLu = { mainViewModel.toutMarquerLue() },
                    onNotifClick = { notif ->
                        mainViewModel.marquerNotifLue(notif.id)
                        if (notif.deepLink.isNotEmpty()) {
                            try { navController.navigate(notif.deepLink) } catch (_: Exception) {}
                        }
                    }
                )
            }

            // PROFILE
            composable(
                route = Screen.Profile.route,
                deepLinks = listOf(navDeepLink { uriPattern = "djassa://profile/wallet" })
            ) {
                val profile = mainViewModel.currentUserProfile
                if (profile == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = EcoGreen) }
                } else {
                    ProfileScreen(
                        utilisateur   = Utilisateur(
                            id = profile.id,
                            nom = profile.fullName,
                            telephone = profile.telephone,
                            email = "",
                            localisation = profile.location,
                            profileImageUrl = profile.profileImageUrl,
                            estVerifie = false,
                            nombreVentes = profile.nombreVentes,
                            note = profile.note,
                            nombreDons = mainViewModel.mesDons.size
                        ),
                        favorisCount  = mainViewModel.favoriIds.size,
                        articlesCount = mainViewModel.mesArticles.size,
                        donsCount     = mainViewModel.mesDons.size,
                        onFavoris       = { navController.navigate(Screen.Favoris.route) },
                        onMesArticles   = { navController.navigate(Screen.MesArticles.route) },
                        onMesDons       = { navController.navigate(Screen.MesDons.route) },
                        onParametres    = { navController.navigate(Screen.Parametres.route) },
                        onDeconnexion   = { mainViewModel.deconnexion(); navController.navigate(Screen.Login.route) { popUpTo(0) } }
                    )
                }
            }

            composable(Screen.Favoris.route) {
                FavorisScreen(
                    articles = mainViewModel.articles.filter { mainViewModel.favoriIds.contains(it.id) },
                    onBack = { navController.popBackStack() },
                    onArticleClick = { id -> navController.navigate(Screen.Detail.createRoute(id)) },
                    onToggleFavorite = { id -> mainViewModel.toggleFavorite(id) }
                )
            }

            composable(Screen.MesArticles.route) {
                MesArticlesScreen(
                    articles = mainViewModel.mesArticles,
                    onBack = { navController.popBackStack() },
                    onPublish = { navController.navigate(Screen.Publish.route) }
                )
            }

            composable(Screen.MesDons.route) {
                MesDonsScreen(
                    dons = mainViewModel.mesDons,
                    onBack = { navController.popBackStack() },
                    onDelete = { id -> mainViewModel.deleteDon(id) }
                )
            }
            
            composable(Screen.Parametres.route) { 
                ParametresScreen(
                    viewModel = mainViewModel,
                    onBack = { navController.popBackStack() },
                    onDeconnexion = {
                        mainViewModel.deconnexion()
                        navController.navigate(Screen.Login.route) { popUpTo(0) }
                    }
                ) 
            }

            // DONS
            composable(Screen.Dons.route) {
                DonsScreen(
                    dons = mainViewModel.donsDisponibles,
                    onDonParticulier = { navController.navigate(Screen.DonForm.createRoute("PARTICULIER")) },
                    onDonAssociation = { navController.navigate(Screen.DonForm.createRoute("ASSOCIATION")) },
                    onVoirTout       = { navController.navigate(Screen.AllDons.route) },
                    onContactDonneur = { don -> navController.navigate(Screen.DonDetail.createRoute(don.id)) }
                )
            }

            composable(Screen.AllDons.route) {
                AllDonsScreen(
                    dons = mainViewModel.donsDisponibles,
                    onBack = { navController.popBackStack() },
                    onContactDonneur = { don -> navController.navigate(Screen.DonDetail.createRoute(don.id)) }
                )
            }

            composable(
                route = Screen.DonForm.route,
                arguments = listOf(navArgument("type") { type = NavType.StringType; defaultValue = "PARTICULIER" })
            ) { backStack ->
                val type = backStack.arguments?.getString("type") ?: "PARTICULIER"
                DonFormScreen(
                    typeDestinataire = type,
                    onBack = { navController.popBackStack() },
                    onSubmit = { don -> 
                        mainViewModel.addDon(don, context)
                        navController.navigate(Screen.ConfirmDon.route)
                    }
                )
            }

            composable(Screen.ConfirmDon.route) {
                ConfirmDonScreen(
                    don = null, 
                    onFinish = { navController.navigate(Screen.Dons.route) { popUpTo(Screen.Dons.route) { inclusive = true } } }
                )
            }

            composable(
                route = Screen.DonDetail.route,
                arguments = listOf(navArgument("donId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("donId") ?: ""
                val don = mainViewModel.donsDisponibles.find { it.id == id }
                if (don != null) {
                    DonDetailScreen(
                        don = don,
                        onBack = { navController.popBackStack() },
                        onContact = { 
                            val donArt = Article(
                                id = "", firestoreId = don.id, titre = don.typeDon, prix = 0,
                                vendeur = don.donateur ?: "Donneur", vendeurId = don.donateurId,
                                initiales = don.donateur?.take(1) ?: "D", couleurVendeur = 0xFF1DB97A,
                                categorie = Categorie.TOUT, etat = don.etat
                            )
                            mainViewModel.demarrerDiscussion(donArt) { convId ->
                                if (convId != null) navController.navigate(Screen.Chat.createRoute(convId))
                            }
                        }
                    )
                }
            }

            // DETAIL
            composable(
                route = Screen.Detail.route,
                arguments = listOf(navArgument("articleId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("articleId") ?: ""
                val article = mainViewModel.articles.find { it.id == id }
                if (article != null) {
                    DetailScreen(
                        article = article,
                        avis = emptyList(), 
                        onBack = { navController.popBackStack() },
                        onMessage = { 
                            mainViewModel.demarrerDiscussion(article) { convId ->
                                if (convId != null) navController.navigate(Screen.Chat.createRoute(convId))
                            }
                        },
                        onBuy = { navController.navigate(Screen.Checkout.createRoute(article.id)) },
                        onNego = { navController.navigate(Screen.Nego.createRoute(article.id)) },
                        onSellerClick = { sellerId ->
                            navController.navigate(Screen.SellerProfile.createRoute(sellerId))
                        }
                    )
                }
            }

            composable(
                route = Screen.SellerProfile.route,
                arguments = listOf(navArgument("sellerId") { type = NavType.StringType })
            ) { backStack ->
                val sellerId = backStack.arguments?.getString("sellerId") ?: ""
                
                var sellerProfile by remember { mutableStateOf<UserProfile?>(null) }
                val flow = remember(sellerId) { firestoreService.getArticlesBySellerFlow(sellerId) }
                val articles by flow.collectAsState(initial = emptyList())
                
                LaunchedEffect(sellerId) {
                    sellerProfile = firestoreService.getUserProfile(sellerId)
                }
                
                if (sellerProfile != null) {
                    SellerProfileScreen(
                        profile = sellerProfile!!,
                        articles = articles,
                        onBack = { navController.popBackStack() },
                        onArticleClick = { id -> navController.navigate(Screen.Detail.createRoute(id)) },
                        onContact = {
                            val dummyArticle = Article(
                                id = "", firestoreId = "", titre = "Profil Vendeur", prix = 0,
                                vendeur = sellerProfile!!.fullName, vendeurId = sellerId,
                                initiales = sellerProfile!!.initiales, couleurVendeur = 0xFF1DB97A,
                                categorie = Categorie.TOUT, etat = EtatArticle.BON_ETAT
                            )
                            mainViewModel.demarrerDiscussion(dummyArticle) { convId ->
                                if (convId != null) navController.navigate(Screen.Chat.createRoute(convId))
                            }
                        }
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = EcoGreen)
                    }
                }
            }

            // CHECKOUT
            composable(
                route = Screen.Checkout.route,
                arguments = listOf(navArgument("articleId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("articleId") ?: ""
                val article = mainViewModel.articles.find { it.id == id }
                if (article != null) {
                    CheckoutScreen(
                        article        = article,
                        userPhone      = mainViewModel.telephonePaiement,
                        deliveryResult = pendingDeliveryResult,
                        onBack         = { navController.popBackStack() },
                        onOpenMap      = { navController.navigate(Screen.DeliveryMap.createRoute(id)) },
                        onPay          = { provider, phone, mode, address ->
                            pendingDeliveryResult = null
                            mainViewModel.acheterArticle(article, provider, phone, mode, address) { success ->
                                if (success) navController.navigate(
                                    Screen.DeliveryTracking.createRoute(article.firestoreId)
                                )
                            }
                        }
                    )
                }
            }

            composable(
                route = Screen.DeliveryMap.route,
                arguments = listOf(navArgument("articleId") { type = NavType.StringType })
            ) {
                DeliveryMapScreen(
                    onBack    = { navController.popBackStack() },
                    onConfirm = { result ->
                        pendingDeliveryResult = result
                        navController.popBackStack()
                    }
                )
            }

            composable(
                route = Screen.DeliveryTracking.route,
                arguments = listOf(navArgument("orderId") { type = NavType.StringType })
            ) { backStack ->
                val orderId = backStack.arguments?.getString("orderId") ?: ""
                DeliveryTrackingScreen(
                    orderId        = orderId,
                    deliveryResult = pendingDeliveryResult ?: DeliveryResult(
                        address = "Abidjan", geoPoint = ABIDJAN_CENTER,
                        distanceKm = 5.0, estimatedMinutes = 30,
                        deliveryFee = 1000, mode = DeliveryMode.STANDARD
                    ),
                    onBack         = { navController.navigate(Screen.Home.route) { popUpTo(0) } },
                    onContactRider = {}
                )
            }

            composable(Screen.Publish.route) { PublishScreen({ navController.popBackStack() }, { mainViewModel.addArticle(it, context); navController.navigate(Screen.ConfirmPub.route) }) }
            composable(Screen.ConfirmPub.route) { ConfirmPublishScreen { navController.navigate(Screen.Home.route) { popUpTo(0) } } }
            
            composable(
                route = Screen.Nego.route, 
                arguments = listOf(navArgument("articleId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("articleId") ?: ""
                val article = mainViewModel.articles.find { it.id == id }
                if (article != null) {
                    NegoScreen(article, { navController.popBackStack() }) { price ->
                        mainViewModel.faireOffre(article, price) { convId ->
                            if (convId != null) navController.navigate(Screen.Chat.createRoute(convId))
                        }
                    }
                }
            }

            composable(
                route = Screen.ConfirmPay.route, 
                arguments = listOf(
                    navArgument("total") { type = NavType.IntType }, 
                    navArgument("articlePrice") { type = NavType.IntType }, 
                    navArgument("shippingFees") { type = NavType.IntType }
                )
            ) { backStack ->
                ConfirmPayScreen(
                    total = backStack.arguments?.getInt("total") ?: 0, 
                    articlePrice = backStack.arguments?.getInt("articlePrice") ?: 0, 
                    shippingFees = backStack.arguments?.getInt("shippingFees") ?: 0,
                    onHome = { navController.navigate(Screen.Home.route) { popUpTo(navController.graph.startDestinationId) { inclusive = false } } },
                    onTrackOrder = { navController.navigate(Screen.DeliveryTracking.createRoute("ORDER_123")) }
                )
            }
        }
    }
}
