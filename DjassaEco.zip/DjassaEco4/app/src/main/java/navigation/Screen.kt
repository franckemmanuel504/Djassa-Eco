package com.djassaeco.navigation

sealed class Screen(val route: String) {
    object Onboarding1 : Screen("onboarding1")
    object Onboarding2 : Screen("onboarding2")
    object Onboarding3 : Screen("onboarding3")
    object Login : Screen("login")
    object Otp : Screen("otp/{verificationId}") {
        fun createRoute(verificationId: String) = "otp/$verificationId"
    }
    object Home : Screen("home")
    object Dons : Screen("dons")
    object AllDons : Screen("all_dons")
    object DonForm : Screen("don_form?type={type}") {
        fun createRoute(type: String) = "don_form?type=$type"
    }
    object DonAssoForm : Screen("don_association_form")
    object ConfirmDon : Screen("confirm_don")
    object DonDetail : Screen("don_detail/{donId}") {
        fun createRoute(donId: String) = "don_detail/$donId"
    }
    object TextileWaste : Screen("textile_waste")
    object Publish : Screen("publish")
    object ConfirmPub : Screen("confirm_pub")
    object Messages : Screen("messages")
    object Notifications : Screen("notifications")
    object Chat : Screen("chat/{convId}") {
        fun createRoute(convId: String) = "chat/$convId"
    }
    object Detail : Screen("detail/{articleId}") {
        fun createRoute(articleId: String) = "detail/$articleId"
    }
    object Nego : Screen("nego/{articleId}") {
        fun createRoute(articleId: String) = "nego/$articleId"
    }
    object Checkout : Screen("checkout/{articleId}") {
        fun createRoute(articleId: String) = "checkout/$articleId"
    }
    object DeliveryMap : Screen("delivery_map/{articleId}") {
        fun createRoute(articleId: String) = "delivery_map/$articleId"
    }
    object DeliveryTracking : Screen("delivery_tracking/{orderId}") {
        fun createRoute(orderId: String) = "delivery_tracking/$orderId"
    }
    object ConfirmPay : Screen("confirm_pay/{total}/{articlePrice}/{shippingFees}") {
        fun createRoute(total: Int, articlePrice: Int, shippingFees: Int) = "confirm_pay/$total/$articlePrice/$shippingFees"
    }
    object Profile : Screen("profile")
    object SellerProfile : Screen("seller_profile/{sellerId}") {
        fun createRoute(sellerId: String) = "seller_profile/$sellerId"
    }
    object Favoris : Screen("favoris")
    object MesArticles : Screen("mes_articles")
    object MesDons : Screen("mes_dons")
    object Parametres : Screen("parametres")
}

val bottomNavList = listOf(
    Screen.Home.route,
    Screen.Dons.route,
    Screen.Messages.route,
    Screen.Profile.route
)
