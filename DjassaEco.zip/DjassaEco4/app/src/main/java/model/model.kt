// File moved to com.djassaeco.data.model package
