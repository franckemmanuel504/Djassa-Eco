package com.djassaeco.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.djassaeco.navigation.Screen
import com.djassaeco.ui.theme.EcoGreen

@Composable
fun DjassaBottomNavBar(
    currentRoute: String?,
    navController: NavController
) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp,
        modifier = Modifier.height(72.dp)
    ) {
        // 1. Accueil
        NavigationBarItem(
            selected = currentRoute == Screen.Home.route,
            onClick  = { navController.navigate(Screen.Home.route) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(24.dp)) },
            label = { Text("Accueil", fontSize = 10.sp) },
            colors = navigationItemColors()
        )

        // 2. Dons
        NavigationBarItem(
            selected = currentRoute == Screen.Dons.route,
            onClick  = { navController.navigate(Screen.Dons.route) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(24.dp)) },
            label = { Text("Dons", fontSize = 10.sp) },
            colors = navigationItemColors()
        )

        // 3. Vendre
        NavigationBarItem(
            selected = currentRoute == Screen.Publish.route,
            onClick  = { navController.navigate(Screen.Publish.route) { launchSingleTop = true } },
            icon = {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(EcoGreen, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
                }
            },
            label = { Text("Vendre", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor   = Color.White,
                selectedTextColor   = EcoGreen,
                unselectedIconColor = Color.White,
                unselectedTextColor = EcoGreen,
                indicatorColor      = Color.Transparent
            )
        )

        // 4. Messages
        NavigationBarItem(
            selected = currentRoute == Screen.Messages.route,
            onClick  = { navController.navigate(Screen.Messages.route) { launchSingleTop = true } },
            icon = { Icon(Icons.AutoMirrored.Filled.Message, contentDescription = null, modifier = Modifier.size(24.dp)) },
            label = { Text("Messages", fontSize = 10.sp) },
            colors = navigationItemColors()
        )

        // 5. Profil
        NavigationBarItem(
            selected = currentRoute == Screen.Profile.route,
            onClick  = { navController.navigate(Screen.Profile.route) { launchSingleTop = true } },
            icon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(24.dp)) },
            label = { Text("Profil", fontSize = 10.sp) },
            colors = navigationItemColors()
        )
    }
}

@Composable
private fun navigationItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor   = EcoGreen,
    selectedTextColor   = EcoGreen,
    unselectedIconColor = Color(0xFFBBBBBB),
    unselectedTextColor = Color(0xFFBBBBBB),
    indicatorColor      = Color.Transparent
)
