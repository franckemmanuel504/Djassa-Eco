package com.djassaeco.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.djassaeco.R
import com.djassaeco.data.model.Article
import com.djassaeco.data.model.EtatArticle
import com.djassaeco.ui.theme.*
import java.util.Locale

@Composable
fun ArticleCard(
    article: Article,
    onClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    var favScaleTrigger by remember { mutableStateOf(false) }
    val animScale by animateFloatAsState(
        targetValue = if (favScaleTrigger) 1.4f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        finishedListener = { favScaleTrigger = false },
        label = "fav_anim"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape     = RoundedCornerShape(0.dp),
        elevation = CardDefaults.cardElevation(0.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            ) {
                if (article.images.isNotEmpty()) {
                    AsyncImage(
                        model = article.images.first(),
                        contentDescription = article.titre,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else if (article.coverImageRes != null) {
                    Image(
                        painter = painterResource(id = article.coverImageRes!!),
                        contentDescription = article.titre,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.logo_app),
                            contentDescription = null,
                            modifier = Modifier.size(40.dp),
                            alpha = 0.3f
                        )
                    }
                }

                IconButton(
                    onClick  = { 
                        favScaleTrigger = true
                        onFavoriteToggle() 
                    },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(30.dp)
                        .scale(animScale)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.92f))
                ) {
                    Icon(
                        imageVector = if (article.estFavori) Icons.Filled.Favorite
                        else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favori",
                        tint   = if (article.estFavori) DangerRed else Color(0xFFCCCCCC),
                        modifier = Modifier.size(15.dp)
                    )
                }

                if (article.estVerifie) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomStart).padding(7.dp),
                        shape = RoundedCornerShape(6.dp),
                        color = AccentBlue
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
                            Icon(Icons.Default.Verified, null, tint = Color.White, modifier = Modifier.size(9.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("Vérifié", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                Text(text = "${article.prix.formatPrixLong()} F", fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = article.titre, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                
                Surface(
                    modifier = Modifier.padding(top = 5.dp),
                    shape    = RoundedCornerShape(4.dp),
                    color    = if (article.etat == EtatArticle.NEUF) ConditionNewBg else ConditionGoodBg
                ) {
                    Text(text = article.etat.label, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = if (article.etat == EtatArticle.NEUF) ConditionNewText else ConditionGoodText, modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp))
                }
            }
        }
    }
}

@Composable
fun ShimmerArticleCard(modifier: Modifier = Modifier) {
    val shimmerColors = listOf(
        Color(0xFFEEEEEE),
        Color(0xFFDDDDDD),
        Color(0xFFEEEEEE),
    )
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue  = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_translate"
    )

    val brush = Brush.linearGradient(
        colors = shimmerColors,
        start  = androidx.compose.ui.geometry.Offset(translateAnim - 200, 0f),
        end    = androidx.compose.ui.geometry.Offset(translateAnim, 0f)
    )

    Card(
        modifier  = modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(0.dp),
        elevation = CardDefaults.cardElevation(0.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(brush)
            )
            Column(modifier = Modifier.padding(12.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.7f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(brush)
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.5f)
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(brush)
                )
            }
        }
    }
}

fun Int.formatPrixLong(): String {
    return String.format(Locale.FRENCH, "%, d", this).trim()
}
