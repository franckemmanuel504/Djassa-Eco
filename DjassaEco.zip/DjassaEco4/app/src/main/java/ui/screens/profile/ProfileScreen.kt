package com.djassaeco.ui.screens.profile

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.Utilisateur
import com.djassaeco.ui.theme.*

@Composable
fun ProfileScreen(
    utilisateur: Utilisateur,
    favorisCount: Int,
    articlesCount: Int,
    donsCount: Int,
    onFavoris: () -> Unit,
    onMesArticles: () -> Unit,
    onMesDons: () -> Unit,
    onParametres: () -> Unit,
    onDeconnexion: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().background(BackgroundLight).verticalScroll(rememberScrollState())
    ) {
        Surface(color = Color.White) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(76.dp).clip(CircleShape).background(EcoGreen),
                    contentAlignment = Alignment.Center
                ) {
                    val initials = if (utilisateur.nom.isNotEmpty()) {
                        utilisateur.nom.split(" ").filter { it.isNotEmpty() }.map { it.first() }.take(2).joinToString("")
                    } else "U"
                    
                    Text(
                        initials,
                        fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(utilisateur.nom, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                Text(utilisateur.localisation, fontSize = 11.sp, color = TextTertiary, modifier = Modifier.padding(top = 3.dp))

                if (utilisateur.estVerifie) {
                    Spacer(Modifier.height(10.dp))
                    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFE8F8F1)) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = EcoGreen, modifier = Modifier.size(13.dp))
                            Text("Vendeur vérifié par Djassa Eco", fontSize = 10.sp, color = EcoGreen, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                HorizontalDivider(color = DividerColor)
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatItem("Ventes",  utilisateur.nombreVentes.toString(), Modifier.weight(1f))
                    Box(modifier = Modifier.width(1.dp).height(40.dp).background(DividerColor).align(Alignment.CenterVertically))
                    StatItem("Note",    "⭐ ${utilisateur.note}", Modifier.weight(1f))
                    Box(modifier = Modifier.width(1.dp).height(40.dp).background(DividerColor).align(Alignment.CenterVertically))
                    StatItem("Dons",    donsCount.toString(), Modifier.weight(1f))
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        Surface(color = Color.White) {
            Column {
                ProfileMenuItem(
                    icon = Icons.Default.Favorite,
                    iconBg = Color(0xFFFFF0F3),
                    label = "Mes favoris",
                    badge = if (favorisCount > 0) favorisCount.toString() else null,
                    badgeBg = Color(0xFFFFF0F3),
                    iconTint = Color(0xFFF44336),
                    onClick = onFavoris
                )
                ProfileMenuItem(
                    icon = Icons.Default.Storefront,
                    iconBg = Color(0xFFE8F8F1),
                    label = "Mes articles",
                    badge = if (articlesCount > 0) articlesCount.toString() else null,
                    badgeBg = Color(0xFFE8F8F1),
                    iconTint = EcoGreen,
                    onClick = onMesArticles
                )
                // --- AJOUT DE MES DONS ---
                ProfileMenuItem(
                    icon = Icons.Default.Redeem,
                    iconBg = Color(0xFFFFF8E6),
                    label = "Mes dons",
                    badge = if (donsCount > 0) donsCount.toString() else null,
                    badgeBg = Color(0xFFFFF8E6),
                    iconTint = Color(0xFFE67E00),
                    onClick = onMesDons
                )
                ProfileMenuItem(
                    icon = Icons.Default.Settings,
                    iconBg = Color(0xFFF5F5F5),
                    label = "Paramètres",
                    iconTint = Color(0xFF888888),
                    onClick = onParametres
                )
                ProfileMenuItem(
                    icon = Icons.AutoMirrored.Filled.Logout,
                    iconBg = Color(0xFFFFF0F0),
                    label = "Déconnexion",
                    labelColor = DangerRed,
                    iconTint = DangerRed,
                    onClick = onDeconnexion
                )
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun StatItem(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
        Text(label, fontSize = 9.sp, color = TextTertiary, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun ProfileMenuItem(
    icon: ImageVector,
    iconBg: Color,
    label: String,
    badge: String? = null,
    badgeBg: Color = Color(0xFFE8F8F1),
    iconTint: Color = DangerRed,
    labelColor: Color = TextPrimary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Box(modifier = Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(iconBg), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(17.dp))
        }
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = labelColor, modifier = Modifier.weight(1f))
        if (badge != null) {
            Surface(shape = RoundedCornerShape(10.dp), color = badgeBg) {
                Text(badge, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (label == "Mes favoris") Color(0xFFF44336) else if (label == "Mes dons") Color(0xFFE67E00) else EcoGreen, modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp))
            }
        }
        if (labelColor != DangerRed) {
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFFCCCCCC), modifier = Modifier.size(18.dp))
        }
    }
    HorizontalDivider(color = DividerColor, modifier = Modifier.padding(start = 65.dp))
}
