package com.djassaeco.ui.screens.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.R
import com.djassaeco.data.FirestoreService
import com.djassaeco.ui.theme.EcoGreen
import com.djassaeco.ui.theme.TextTertiary
import com.google.firebase.auth.*
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    onRegisterSuccess: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(EcoGreen)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.logo_app),
                    contentDescription = "Djassa Eco Logo",
                    modifier = Modifier.height(180.dp)
                )
                Spacer(Modifier.height(4.dp))
                Text("Donne une 2ème vie à tes objets !", fontSize = 12.sp, color = Color.White.copy(alpha = .85f))
            }
        }

        TabRow(selectedTabIndex = selectedTab, containerColor = Color.White, contentColor = EcoGreen) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                text = { Text("CONNEXION", fontWeight = FontWeight.Bold, fontSize = 13.sp) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                text = { Text("INSCRIPTION", fontWeight = FontWeight.Bold, fontSize = 13.sp) })
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (selectedTab == 0) {
                LoginForm(onLogin = onLoginSuccess)
            } else {
                RegisterForm(onRegister = onRegisterSuccess)
            }
        }
    }
}

@Composable
fun LoginForm(onLogin: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val auth = FirebaseAuth.getInstance()

    AuthTextField(label = "E-Mail", value = email, onValueChange = { email = it }, placeholder = "votre@email.com", keyboardType = KeyboardType.Email)
    AuthTextField(label = "Mot de passe", value = password, onValueChange = { password = it }, placeholder = "••••••••", isPassword = true)

    if (errorMessage != null) {
        Text(errorMessage!!, color = Color.Red, fontSize = 12.sp)
    }

    Button(
        onClick  = { 
            if (email.isNotEmpty() && password.isNotEmpty()) {
                isLoading = true
                errorMessage = null
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        isLoading = false
                        if (task.isSuccessful) {
                            onLogin()
                        } else {
                            errorMessage = "Email ou mot de passe incorrect"
                        }
                    }
            }
        },
        enabled = !isLoading,
        modifier = Modifier.fillMaxWidth().height(50.dp),
        shape    = RoundedCornerShape(13.dp),
        colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen)
    ) {
        if (isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
        else Text("Se Connecter", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun RegisterForm(onRegister: () -> Unit) {
    val auth = FirebaseAuth.getInstance()
    val firestoreService = remember { FirestoreService() }
    val scope = rememberCoroutineScope()
    
    var nom by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var tel by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AuthTextField("Nom & Prénom", nom, { nom = it }, "Kofi Asante")
    AuthTextField("E-Mail", email, { email = it }, "kofi@email.com", KeyboardType.Email)
    AuthTextField("Téléphone", tel, { tel = it }, "07 00 00 00 00", KeyboardType.Phone)
    AuthTextField("Mot de passe", password, { password = it }, "Minimum 8 caractères", isPassword = true)

    if (errorMessage != null) {
        Text(errorMessage!!, color = Color.Red, fontSize = 12.sp)
    }

    Spacer(Modifier.height(10.dp))

    Button(
        onClick  = {
            if (nom.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                isLoading = true
                errorMessage = null
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val uid = auth.currentUser?.uid ?: ""
                            // Sauvegarde du profil dans Firestore
                            scope.launch {
                                val saved = firestoreService.saveUserProfile(uid, nom, email, tel)
                                isLoading = false
                                if (saved) {
                                    onRegister()
                                } else {
                                    errorMessage = "Compte créé mais erreur profil. Contactez le support."
                                }
                            }
                        } else {
                            isLoading = false
                            errorMessage = task.exception?.localizedMessage ?: "Erreur d'inscription"
                        }
                    }
            }
        },
        enabled = !isLoading,
        modifier = Modifier.fillMaxWidth().height(50.dp),
        shape    = RoundedCornerShape(13.dp),
        colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen)
    ) {
        if (isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
        else Text("Créer mon Compte", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun AuthTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    isPassword: Boolean = false
) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF888888), letterSpacing = .5.sp)
        OutlinedTextField(
            value         = value,
            onValueChange = onValueChange,
            placeholder   = { Text(placeholder, color = Color(0xFFBBBBBB), fontSize = 13.sp) },
            visualTransformation = if (isPassword) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(12.dp),
            colors   = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color(0xFFEEEEEE),
                focusedBorderColor   = EcoGreen,
                unfocusedContainerColor = Color(0xFFFAFAFA),
                focusedContainerColor   = Color.White
            ),
            singleLine = true
        )
    }
}
