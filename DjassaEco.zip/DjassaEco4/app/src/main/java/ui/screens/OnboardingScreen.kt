package com.djassaeco.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.ui.theme.*

data class OnboardingData(
    val emoji: String,
    val titre: String,
    val description: String,
    val backgroundColor: Color,
    val emojiColor: Color
)

val onboardingPages = listOf(
    OnboardingData(
        emoji           = "♻️",
        titre           = "Donne une seconde vie à tes objets",
        description     = "Tu n'utilises plus quelque chose ? Quelqu'un d'autre en a besoin. Vends, donne, échange — ici, rien ne se perd à Abidjan.",
        backgroundColor = Color(0xFFE8F8F1),
        emojiColor      = EcoGreen
    ),
    OnboardingData(
        emoji           = "💰",
        titre           = "Gagne de l'argent facilement",
        description     = "Publie ton annonce et vends en toute sécurité.",
        backgroundColor = Color(0xFFFFF8E6),
        emojiColor      = Color(0xFFE67E00)
    ),
    OnboardingData(
        emoji           = "🌍",
        titre           = "Impact écologique à Abidjan",
        description     = "Chaque achat de seconde main, c'est un objet sauvé. Ensemble, construisons une ville plus propre et solidaire.",
        backgroundColor = Color(0xFFE8F2FF),
        emojiColor      = AccentBlue
    )
)

@Composable
fun OnboardingScreen(
    page: Int,
    onNext: () -> Unit,
    onSkip: (() -> Unit)?
) {
    // Sécurité pour éviter les index hors limites
    val data = onboardingPages.getOrElse(page - 1) { onboardingPages[0] }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        // Illustration
        Box(
            modifier = Modifier
                .size(140.dp)
                .clip(RoundedCornerShape(36.dp))
                .background(data.backgroundColor),
            contentAlignment = Alignment.Center
        ) {
            Text(data.emoji, fontSize = 64.sp)
        }

        Spacer(Modifier.height(36.dp))

        // Titre
        Text(
            text       = data.titre,
            style      = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            textAlign  = TextAlign.Center,
            color      = TextPrimary,
            lineHeight = 32.sp
        )

        Spacer(Modifier.height(16.dp))

        // Description
        Text(
            text      = data.description,
            style     = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color     = TextTertiary,
            lineHeight = 22.sp
        )

        Spacer(Modifier.height(44.dp))

        // Indicateurs de page (Synchronisés sur 3 pages)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(onboardingPages.size) { index ->
                val isSelected = index + 1 == page
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .size(if (isSelected) 24.dp else 8.dp, 8.dp)
                        .background(if (isSelected) EcoGreen else Color(0xFFE0E0E0))
                )
            }
        }

        Spacer(Modifier.height(44.dp))

        // Bouton principal
        Button(
            onClick  = onNext,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape  = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)
        ) {
            Text(
                if (page == onboardingPages.size) "Commencer" else "Suivant",
                fontWeight = FontWeight.Bold,
                fontSize   = 15.sp
            )
        }

        // Bouton passer
        if (onSkip != null) {
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onSkip) {
                Text("Passer", color = TextTertiary, fontSize = 13.sp)
            }
        }
    }
}
