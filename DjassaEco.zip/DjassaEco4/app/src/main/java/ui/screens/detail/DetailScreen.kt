// Fichier déplacé vers com.djassaeco.ui.screens.detail.DetailScreen.kt
// Contenu supprimé pour éviter les conflits d'overload.
package com.djassaeco.ui.screens.detail
