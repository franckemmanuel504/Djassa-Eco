package com.djassaeco.ui.screens.chat

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MessagesScreen(
    conversations: List<ConversationMetadata>,
    onConvClick: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    
    val filteredConversations = remember(searchQuery, conversations) {
        if (searchQuery.isEmpty()) conversations
        else conversations.filter { 
            it.otherUserName.contains(searchQuery, ignoreCase = true) ||
            it.lastMessage.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Surface(color = Color.White) {
            Column(modifier = Modifier.padding(horizontal = 16.dp).padding(top = 16.dp, bottom = 12.dp)) {
                Text("Messages", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher un vendeur...", color = TextHint, fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextHint, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = Color(0xFFF4F4F4),
                        focusedContainerColor = Color(0xFFF4F4F4),
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = EcoGreen
                    ),
                    singleLine = true
                )
            }
            HorizontalDivider(color = DividerColor)
        }

        if (filteredConversations.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aucune conversation", color = TextTertiary, fontSize = 14.sp)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredConversations, key = { it.id }) { conv ->
                    ConvItem(conv = conv, onClick = { onConvClick(conv.id) })
                    HorizontalDivider(color = DividerColor, modifier = Modifier.padding(start = 72.dp))
                }
            }
        }
    }
}

@Composable
fun ConvItem(conv: ConversationMetadata, onClick: () -> Unit) {
    val sdf = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val timeStr = remember(conv.lastMessageTimestamp) { sdf.format(conv.lastMessageTimestamp.toDate()) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFE8F8F1)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                conv.otherUserName.take(1).uppercase(), 
                fontSize = 15.sp, 
                fontWeight = FontWeight.Bold, 
                color = EcoGreen
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(conv.otherUserName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextPrimary)
            Text(
                conv.lastMessage,
                fontSize = 11.sp,
                color = TextTertiary,
                modifier = Modifier.padding(top = 2.dp),
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }

        Text(timeStr, fontSize = 10.sp, color = TextTertiary)
    }
}
