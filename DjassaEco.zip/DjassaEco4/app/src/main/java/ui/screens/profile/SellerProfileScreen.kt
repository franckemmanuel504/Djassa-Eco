package com.djassaeco.ui.screens.profile

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.djassaeco.R
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*

@Composable
fun SellerProfileScreen(
    profile: UserProfile,
    articles: List<Article>,
    onBack: () -> Unit,
    onArticleClick: (String) -> Unit,
    onContact: () -> Unit
) {
    Scaffold(
        topBar = {
            Surface(shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                    Text(profile.fullName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().background(Color.White)) {
            // Header Style Instagram
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Photo de profil
                if (profile.profileImageUrl != null) {
                    AsyncImage(
                        model = profile.profileImageUrl,
                        contentDescription = null,
                        modifier = Modifier.size(80.dp).clip(CircleShape).border(1.dp, Color.LightGray, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(modifier = Modifier.size(80.dp).clip(CircleShape).background(EcoGreen), contentAlignment = Alignment.Center) {
                        Text(profile.initiales, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                Spacer(Modifier.width(24.dp))

                // Stats
                Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceAround) {
                    StatColumn("Publications", articles.size.toString())
                    StatColumn("Abonnés", "1.2k")
                    StatColumn("Suivi(e)s", "450")
                }
            }

            // Bio
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(profile.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(profile.location, fontSize = 13.sp, color = Color.Gray)
                Text("Vendeur certifié sur DjassaEco ✅", fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            }

            Spacer(Modifier.height(16.dp))

            // Boutons d'action
            Row(modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onContact,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)
                ) {
                    Text("Contacter", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { /* S'abonner */ },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("S'abonner", color = Color.Black)
                }
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = Color.LightGray.copy(0.5f))

            // Grille d'articles
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(1.dp),
                horizontalArrangement = Arrangement.spacedBy(1.dp),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                items(articles) { article ->
                    Box(modifier = Modifier.aspectRatio(1f).clickable { onArticleClick(article.id) }) {
                        if (article.images.isNotEmpty()) {
                            AsyncImage(
                                model = article.images.first(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Image, null, tint = Color.LightGray)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatColumn(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(label, fontSize = 12.sp, color = Color.Gray)
    }
}
