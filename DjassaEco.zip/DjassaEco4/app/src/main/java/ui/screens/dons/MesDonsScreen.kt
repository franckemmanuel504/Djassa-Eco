package com.djassaeco.ui.screens.dons

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.Don
import com.djassaeco.ui.theme.*

@Composable
fun MesDonsScreen(
    dons: List<Don>,
    onBack: () -> Unit,
    onDelete: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        Surface(color = Color.White) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
                Text("Mes dons", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            HorizontalDivider(color = DividerColor)
        }

        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            if (dons.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Vous n'avez pas encore fait de don", color = TextTertiary, fontSize = 14.sp)
                }
            } else {
                dons.forEach { don ->
                    MyDonItem(don = don, onDelete = { onDelete(don.id) })
                }
            }
        }
    }
}

@Composable
private fun MyDonItem(don: Don, onDelete: () -> Unit) {
    Surface(color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Avatar (Rectangulaire arrondi comme Mes Articles)
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFE8F8F1)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    don.typeDon.take(1).uppercase(),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcoGreen
                )
            }

            // Infos
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    don.typeDon,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = EcoGreen
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    don.localisation,
                    fontSize = 12.sp,
                    color = TextTertiary
                )
            }

            // Actions
            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFE8F8F1)
                ) {
                    Text(
                        "Disponible",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcoGreen,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                Spacer(Modifier.height(8.dp))
                // Boutons regroupés
                Row(
                    modifier = Modifier
                        .border(1.dp, Color(0xFFEEEEEE), RoundedCornerShape(10.dp))
                        .height(36.dp)
                        .width(80.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxHeight().clickable { /* Edit logic */ },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = EcoGreen, modifier = Modifier.size(16.dp))
                    }
                    Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color(0xFFEEEEEE)))
                    Box(
                        modifier = Modifier.weight(1f).fillMaxHeight().clickable { onDelete() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = DangerRed, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        HorizontalDivider(color = DividerColor, modifier = Modifier.padding(start = 92.dp))
    }
}
