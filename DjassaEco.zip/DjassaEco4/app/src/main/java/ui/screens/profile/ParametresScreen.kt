package com.djassaeco.ui.screens.profile

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.ui.theme.*

import com.djassaeco.ui.viewmodels.MainViewModel
import java.util.UUID

// ─────────────────────────────────────────────────────────────────
//  MODÈLES LOCAUX
// ─────────────────────────────────────────────────────────────────

data class Adresse(
    val id: String,
    val libelle: String,
    val details: String,
    val estPrincipale: Boolean = false
)

data class ModePaiementEnregistre(
    val id: String,
    val type: String,
    val numero: String,
    val estPrincipal: Boolean = false
)

// ─────────────────────────────────────────────────────────────────
//  ÉCRAN PRINCIPAL
// ─────────────────────────────────────────────────────────────────

@Composable
fun ParametresScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit, 
    onDeconnexion: () -> Unit = {}
) {
    var step by remember { mutableIntStateOf(0) }

    val stepTitle = when (step) {
        1    -> "Certification Djassa Eco"
        2    -> "Informations personnelles"
        3    -> "Changer le mot de passe"
        4    -> "Mes adresses"
        5    -> "Modes de paiement"
        6    -> "Demande envoyée"
        else -> "Paramètres"
    }

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        // Header
        Surface(color = Color.White, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { if (step > 0 && step != 6) step = 0 else if (step == 6) step = 0 else onBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
                Text(stepTitle, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
            }
        }

        when (step) {
            0 -> SettingsMenu(
                onStartCertification = { step = 1 },
                onShowInfos          = { step = 2 },
                onShowPassword       = { step = 3 },
                onShowAdresses       = { step = 4 },
                onShowPaiements      = { step = 5 },
                onDeconnexion        = onDeconnexion
            )
            1 -> CertificationQuestionnaire(
                viewModel = viewModel,
                onSubmitted = { step = 6 }
            )
            2 -> UserInfoScreen(onSave = { step = 0 })
            3 -> ChangePasswordScreen(onSave = { step = 0 })
            4 -> MesAdressesScreen()
            5 -> ModesPaiementScreen()
            6 -> ConfirmationCertification(onFinish = { step = 0 })
        }
    }
}

// ─────────────────────────────────────────────────────────────────
//  CERTIFICATION (Logique Claude améliorée)
// ─────────────────────────────────────────────────────────────────

@Composable
fun CertificationQuestionnaire(viewModel: MainViewModel, onSubmitted: () -> Unit) {
    var nomComplet by remember { mutableStateOf("") }
    var numeroCni  by remember { mutableStateOf("") }
    var adresse    by remember { mutableStateOf("") }
    var activite   by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    val isValid = nomComplet.isNotBlank() && numeroCni.isNotBlank() &&
                  adresse.isNotBlank() && activite.isNotBlank() && !isSubmitting

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Bannière de confiance
        Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFE8F8F1)) {
            Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.Verified, null, tint = EcoGreen, modifier = Modifier.size(20.dp))
                Column {
                    Text("Badge de confiance Djassa Eco", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EcoGreen)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Le badge ✓ rassure les acheteurs et augmente vos ventes. Nous vérifierons vos informations sous 48h.",
                        fontSize = 11.sp, color = Color(0xFF1A7A50)
                    )
                }
            }
        }

        // Formulaire dans une carte
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("VOS INFORMATIONS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, letterSpacing = .5.sp)
                CertifField("Nom complet (sur la pièce)", nomComplet, { nomComplet = it }, "Ex: Kofi Asante")
                CertifField("Numéro CNI / Passeport", numeroCni, { numeroCni = it }, "Ex: CI0012345678")
                CertifField("Adresse résidence", adresse, { adresse = it }, "Ex: Cocody Angré, Abidjan")
                CertifField("Activité principale", activite, { activite = it }, "Ex: Vendeur de vêtements / Couturier")
            }
        }

        // Note sécurité
        Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFFF8E6)) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Security, null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                Text(
                    "Vos données sont chiffrées et ne seront jamais partagées publiquement.",
                    fontSize = 11.sp, color = Color(0xFF92400E)
                )
            }
        }

        Button(
            onClick = {
                isSubmitting = true
                viewModel.soumettreCertification(nomComplet, numeroCni, adresse, activite) { success ->
                    isSubmitting = false
                    if (success) onSubmitted()
                }
            },
            enabled = isValid,
            modifier = Modifier.fillMaxWidth().height(52.dp).padding(top = 10.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen, disabledContainerColor = Color.LightGray)
        ) {
            if (isSubmitting) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                Icon(Icons.Default.Send, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Soumettre ma demande", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ConfirmationCertification(onFinish: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(100.dp).clip(CircleShape).background(Color(0xFFE8F8F1)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Verified, null, tint = EcoGreen, modifier = Modifier.size(50.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Demande envoyée !", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextPrimary)
        Spacer(Modifier.height(12.dp))
        Text(
            "Votre dossier est en cours d'examen. Vous recevrez une notification d'ici 24 à 48h.",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            color = TextSecondary,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = onFinish,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)
        ) {
            Text("Retour aux paramètres", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CertifField(label: String, value: String, onChange: (String) -> Unit, placeholder: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, letterSpacing = .5.sp)
        OutlinedTextField(
            value = value, onValueChange = onChange,
            placeholder = { Text(placeholder, color = Color.LightGray, fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color(0xFFE0E0E0),
                focusedBorderColor = EcoGreen,
                unfocusedContainerColor = Color(0xFFFAFAFA)
            ),
            singleLine = true
        )
    }
}

// ─────────────────────────────────────────────────────────────────
//  MENU & AUTRES (Gardés tels quels)
// ─────────────────────────────────────────────────────────────────

@Composable
private fun SettingsMenu(
    onStartCertification: () -> Unit,
    onShowInfos: () -> Unit,
    onShowPassword: () -> Unit,
    onShowAdresses: () -> Unit,
    onShowPaiements: () -> Unit,
    onDeconnexion: () -> Unit
) {
    var showLogoutDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        SettingsSection("Compte & Sécurité") {
            SettingsRow(Icons.Default.Person, "Informations personnelles", onClick = onShowInfos)
            SettingsRow(Icons.Default.Lock, "Mot de passe", onClick = onShowPassword)
            SettingsRow(Icons.Default.Verified, "Certification Djassa Eco", badge = "Obtenir le badge", onClick = onStartCertification)
        }
        SettingsSection("Livraison & Paiement") {
            SettingsRow(Icons.Default.LocationOn, "Mes adresses", subtitle = "Points de rencontre ou livraison", onClick = onShowAdresses)
            SettingsRow(Icons.Default.AccountBalanceWallet, "Modes de paiement", subtitle = "Orange Money, Wave, MTN...", onClick = onShowPaiements)
        }
        SettingsSection("Notifications") {
            ToggleRow("Nouveaux messages", true)
            ToggleRow("Alertes de prix", false)
            ToggleRow("Offres reçues", true)
        }
        SettingsSection("Support") {
            SettingsRow(Icons.AutoMirrored.Filled.Help, "Centre d'aide")
            SettingsRow(Icons.Default.Description, "Conditions d'utilisation")
            SettingsRow(Icons.Default.PrivacyTip, "Politique de confidentialité")
        }
        Spacer(Modifier.height(20.dp))
        Surface(color = Color.White) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showLogoutDialog = true }
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFFFF0F0)), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.Logout, null, tint = DangerRed, modifier = Modifier.size(18.dp))
                }
                Text("Déconnexion", fontSize = 14.sp, color = DangerRed, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = {}, modifier = Modifier.padding(horizontal = 16.dp), colors = ButtonDefaults.textButtonColors(contentColor = DangerRed)) {
            Text("Supprimer mon compte", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(32.dp))
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            icon = { Icon(Icons.AutoMirrored.Filled.Logout, null, tint = DangerRed) },
            title = { Text("Se déconnecter ?", fontWeight = FontWeight.Bold) },
            text = { Text("Vous devrez vous reconnecter pour accéder à votre compte.", color = TextSecondary, fontSize = 14.sp) },
            confirmButton = {
                Button(onClick = { showLogoutDialog = false; onDeconnexion() }, colors = ButtonDefaults.buttonColors(containerColor = DangerRed)) {
                    Text("Déconnexion", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun MesAdressesScreen() {
    var adresses by remember {
        mutableStateOf(
            listOf(
                Adresse("1", "Domicile", "Cocody Angré, Rue des jardins 12", estPrincipale = true),
                Adresse("2", "Bureau", "Plateau, Avenue Terrasson de Fougères")
            )
        )
    }
    var showAddDialog by remember { mutableStateOf(false) }
    var newLibelle by remember { mutableStateOf("") }
    var newDetails by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        Spacer(Modifier.height(12.dp))
        adresses.forEach { adresse ->
            AdresseCard(adresse, onSetPrincipale = { adresses = adresses.map { it.copy(estPrincipale = it.id == adresse.id) } }, onDelete = { adresses = adresses.filter { it.id != adresse.id } })
            Spacer(Modifier.height(8.dp))
        }
        Surface(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { showAddDialog = true }, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.5.dp, EcoGreen.copy(.4f)), color = Color.White) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(36.dp).clip(CircleShape).background(EcoGreen.copy(.1f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Add, null, tint = EcoGreen, modifier = Modifier.size(20.dp)) }
                Text("Ajouter une adresse", fontSize = 14.sp, color = EcoGreen, fontWeight = FontWeight.SemiBold)
            }
        }
    }
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Nouvelle adresse") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = newLibelle, onValueChange = { newLibelle = it }, label = { Text("Libellé") })
                    OutlinedTextField(value = newDetails, onValueChange = { newDetails = it }, label = { Text("Adresse") })
                }
            },
            confirmButton = { Button(onClick = { if(newLibelle.isNotBlank()){ adresses += Adresse(UUID.randomUUID().toString(), newLibelle, newDetails); showAddDialog = false } }) { Text("OK") } }
        )
    }
}

@Composable
private fun AdresseCard(adresse: Adresse, onSetPrincipale: () -> Unit, onDelete: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(14.dp), color = Color.White, border = if (adresse.estPrincipale) BorderStroke(1.5.dp, EcoGreen) else null) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(if (adresse.libelle == "Domicile") Icons.Default.Home else Icons.Default.LocationOn, null, tint = if (adresse.estPrincipale) EcoGreen else Color.Gray)
            Column(modifier = Modifier.weight(1f)) {
                Text(adresse.libelle, fontWeight = FontWeight.Bold)
                Text(adresse.details, fontSize = 12.sp, color = Color.Gray)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Color.Red.copy(0.6f)) }
        }
    }
}

@Composable
private fun ModesPaiementScreen() {
    var paiements by remember {
        mutableStateOf(
            listOf(
                ModePaiementEnregistre("1", "Orange Money", "07 44 32 10 89", estPrincipal = true),
                ModePaiementEnregistre("2", "Wave", "01 56 78 90 12")
            )
        )
    }
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedType by remember { mutableStateOf("Orange Money") }
    var newNumero by remember { mutableStateOf("") }
    val typeColors = mapOf("Orange Money" to Color(0xFFFF6B00), "Wave" to Color(0xFF2563EB), "MTN Mobile Money" to Color(0xFFFFCC00))
    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        Spacer(Modifier.height(12.dp))
        Surface(color = Color(0xFFFFFBEB), shape = RoundedCornerShape(12.dp), modifier = Modifier.padding(horizontal = 16.dp)) {
            Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.Security, null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                Text("Vos numéros sont chiffrés et utilisés uniquement pour faciliter vos paiements.", fontSize = 12.sp, color = Color(0xFF92400E))
            }
        }
        Spacer(Modifier.height(14.dp))
        paiements.forEach { p ->
            PaiementCard(p, typeColors[p.type] ?: EcoGreen, onSetPrincipal = { paiements = paiements.map { it.copy(estPrincipal = it.id == p.id) } }, onDelete = { paiements = paiements.filter { it.id != p.id } })
            Spacer(Modifier.height(8.dp))
        }
        Surface(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { showAddDialog = true }, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.5.dp, EcoGreen.copy(.4f)), color = Color.White) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Add, null, tint = EcoGreen)
                Text("Ajouter un mode de paiement", color = EcoGreen, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun PaiementCard(p: ModePaiementEnregistre, color: Color, onSetPrincipal: () -> Unit, onDelete: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(14.dp), color = Color.White, border = if (p.estPrincipal) BorderStroke(1.5.dp, EcoGreen) else null) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(color))
            Column(modifier = Modifier.weight(1f)) {
                Text(p.type, fontWeight = FontWeight.Bold)
                Text(p.numero, fontSize = 12.sp, color = Color.Gray)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Color.Red.copy(0.6f)) }
        }
    }
}

@Composable
fun UserInfoScreen(onSave: () -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(modifier = Modifier.padding(20.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nom complet") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Enregistrer") }
    }
}

@Composable
fun ChangePasswordScreen(onSave: () -> Unit) {
    var pass by remember { mutableStateOf("") }
    Column(modifier = Modifier.padding(20.dp)) {
        OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Nouveau mot de passe") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Mettre à jour") }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.padding(top = 10.dp)) {
        Text(title.uppercase(), modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        Surface(color = Color.White) { Column { content() } }
    }
}

@Composable
fun SettingsRow(icon: ImageVector, title: String, subtitle: String? = null, badge: String? = null, onClick: () -> Unit = {}) {
    Row(modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp)
            if (subtitle != null) Text(subtitle, fontSize = 11.sp, color = Color.Gray)
        }
        if (badge != null) Text(badge, fontSize = 12.sp, color = EcoGreen)
        Icon(Icons.Default.ChevronRight, null, tint = Color.LightGray)
    }
}

@Composable
fun ToggleRow(label: String, checked: Boolean) {
    var isChecked by remember { mutableStateOf(checked) }
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = isChecked, onCheckedChange = { isChecked = it })
    }
}
