package com.djassaeco.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.Article
import com.djassaeco.ui.theme.BackgroundLight
import com.djassaeco.ui.theme.DividerColor
import com.djassaeco.ui.theme.TextPrimary
import com.djassaeco.ui.theme.TextTertiary
import com.djassaeco.ui.components.ArticleCard

@Composable
fun FavorisScreen(
    articles: List<Article>,
    onBack: () -> Unit,
    onArticleClick: (String) -> Unit,
    onToggleFavorite: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        // Header
        Surface(color = Color.White, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
                Text("Mes favoris", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
            }
        }

        if (articles.isEmpty()) {
            // État vide
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("❤️", fontSize = 64.sp)
                    Spacer(Modifier.height(16.dp))
                    Text("Aucun favori pour le moment", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Tes articles coup de cœur s'afficheront ici.", color = TextTertiary, fontSize = 13.sp)
                }
            }
        } else {
            // Grille des favoris
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize()
            ) {
                items(articles, key = { it.id }) { article ->
                    ArticleCard(
                        article = article.copy(estFavori = true), // Ils sont tous favoris ici
                        onClick = { onArticleClick(article.id) },
                        onFavoriteToggle = { onToggleFavorite(article.id) },
                        modifier = Modifier.border(0.5.dp, DividerColor)
                    )
                }
            }
        }
    }
}
