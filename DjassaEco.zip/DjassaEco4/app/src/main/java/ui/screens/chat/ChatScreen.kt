package com.djassaeco.ui.screens.chat

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.FirestoreService
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun ChatScreen(
    conversationId: String,
    onBack: () -> Unit,
    onNego: (String) -> Unit,
    onBuy: (String) -> Unit
) {
    val firestoreService = remember { FirestoreService() }
    val currentUid = remember { FirebaseAuth.getInstance().currentUser?.uid ?: "" }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var inputText by remember { mutableStateOf("") }
    
    var conversationMetadata by remember { mutableStateOf<ConversationMetadata?>(null) }
    var isLoadingMetadata by remember { mutableStateOf(true) }

    // Charger les métadonnées de la conversation
    LaunchedEffect(conversationId) {
        isLoadingMetadata = true
        try {
            val doc = FirebaseFirestore.getInstance()
                .collection("conversations")
                .document(conversationId)
                .get()
                .await()
            conversationMetadata = doc.toObject(ConversationMetadata::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            isLoadingMetadata = false
        }
    }

    val messages by firestoreService.getMessagesFlow(conversationId).collectAsState(initial = emptyList())

    // Auto-scroll vers le bas lors de nouveaux messages
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    if (isLoadingMetadata) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = EcoGreen)
        }
    } else if (conversationMetadata == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Conversation introuvable")
        }
    } else {
        val metadata = conversationMetadata!!
        Column(modifier = Modifier.fillMaxSize().background(Color(0xFFF7F7F7))) {
            // Header
            Surface(color = Color.White, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, modifier = Modifier.size(18.dp))
                    }
                    Box(Modifier.size(38.dp).clip(CircleShape).background(EcoGreen.copy(0.1f)), contentAlignment = Alignment.Center) {
                        Text(metadata.otherUserName.take(1).uppercase(), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EcoGreen)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(metadata.otherUserName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextPrimary)
                        Text("Discussion en cours", fontSize = 10.sp, color = TextTertiary)
                    }
                }
            }

            // Actions rapides
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(
                    onClick = { onNego(metadata.itemId) },
                    label = { Text("Négocier") },
                    leadingIcon = { Icon(Icons.Default.Payments, null, modifier = Modifier.size(16.dp)) }
                )
                AssistChip(
                    onClick = { onBuy(metadata.itemId) },
                    label = { Text("Acheter") },
                    leadingIcon = { Icon(Icons.Default.ShoppingCart, null, modifier = Modifier.size(16.dp)) }
                )
            }

            // Liste des messages
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                items(messages) { msg ->
                    ChatBubble(msg = msg, isMine = msg.senderId == currentUid)
                }
            }

            // Zone de saisie
            Surface(color = Color.White, tonalElevation = 2.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp).navigationBarsPadding(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        placeholder = { Text("Écrivez votre message...", fontSize = 14.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xFFF4F4F4),
                            focusedContainerColor = Color(0xFFF4F4F4),
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = EcoGreen
                        ),
                        maxLines = 3
                    )
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                val msgText = inputText
                                inputText = ""
                                scope.launch {
                                    firestoreService.sendMessage(
                                        conversationId = conversationId,
                                        message = ChatMessage(senderId = currentUid, text = msgText)
                                    )
                                }
                            }
                        },
                        modifier = Modifier.size(48.dp).background(EcoGreen, CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage, isMine: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp, 
                topEnd = 16.dp, 
                bottomStart = if (isMine) 16.dp else 2.dp, 
                bottomEnd = if (isMine) 2.dp else 16.dp
            ),
            color = if (isMine) EcoGreen else Color.White,
            tonalElevation = if (isMine) 0.dp else 1.dp,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                    text = msg.text, 
                    color = if (isMine) Color.White else TextPrimary,
                    fontSize = 14.sp
                )
            }
        }
    }
}
