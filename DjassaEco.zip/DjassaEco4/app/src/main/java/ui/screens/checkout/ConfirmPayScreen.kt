package com.djassaeco.ui.screens.checkout

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.ui.theme.EcoGreen
import com.djassaeco.ui.theme.TextPrimary
import com.djassaeco.ui.theme.TextSecondary
import com.djassaeco.ui.theme.TextTertiary

@Composable
fun ConfirmPayScreen(
    total: Int, 
    articlePrice: Int, 
    shippingFees: Int, 
    onHome: () -> Unit,
    onTrackOrder: () -> Unit
) {
    var rating by remember { mutableIntStateOf(0) }
    var comment by remember { mutableStateOf("") }
    var isSubmitted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Icône Succès
        Box(
            modifier = Modifier.size(80.dp).clip(RoundedCornerShape(50)).background(EcoGreen),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
        }

        Spacer(Modifier.height(20.dp))
        Text("Paiement réussi !", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = TextPrimary)
        
        Spacer(Modifier.height(16.dp))
        
        // --- RÉCAPITULATIF TRANSPARENT ---
        Surface(
            color = Color(0xFFF9F9F9),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Prix article", color = TextSecondary, fontSize = 14.sp)
                    Text("$articlePrice F CFA", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Frais de livraison", color = TextSecondary, fontSize = 14.sp)
                    Text(if (shippingFees == 0) "Gratuit" else "$shippingFees F CFA", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color(0xFFEEEEEE))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total payé", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("$total F CFA", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = EcoGreen)
                }
            }
        }

        if (shippingFees > 0) {
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onTrackOrder,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8F2FF), contentColor = Color(0xFF378ADD))
            ) {
                Icon(Icons.Default.LocalShipping, null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Suivre ma commande", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(32.dp))
        HorizontalDivider(color = Color(0xFFEEEEEE))
        Spacer(Modifier.height(24.dp))

        if (!isSubmitted) {
            Text("Notez votre expérience", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextPrimary)
            Spacer(Modifier.height(12.dp))
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(5) { index ->
                    val starIndex = index + 1
                    Icon(
                        imageVector = if (starIndex <= rating) Icons.Default.Star else Icons.Default.StarOutline,
                        contentDescription = null,
                        tint = if (starIndex <= rating) Color(0xFFFFB300) else Color(0xFFCCCCCC),
                        modifier = Modifier
                            .size(36.dp)
                            .clickable { rating = starIndex }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            OutlinedTextField(
                value = comment,
                onValueChange = { comment = it },
                placeholder = { Text("Laissez un petit mot sur le vendeur ou l'article...", fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EcoGreen,
                    unfocusedBorderColor = Color(0xFFEEEEEE)
                )
            )

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { if(rating > 0) isSubmitted = true },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                enabled = rating > 0
            ) {
                Text("Envoyer mon avis", fontWeight = FontWeight.Bold)
            }
        } else {
            Surface(
                color = Color(0xFFF0FDF8),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Merci pour votre avis ! ❤️\nCela aide la communauté Djassa Eco.",
                    modifier = Modifier.padding(20.dp),
                    textAlign = TextAlign.Center,
                    color = EcoGreen,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(Modifier.height(40.dp))

        TextButton(onClick = onHome) {
            Text("Retour à l'accueil", color = TextTertiary, fontSize = 14.sp)
        }
    }
}
