package com.djassaeco.ui.screens.dons

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.Don
import com.djassaeco.ui.theme.BackgroundLight
import com.djassaeco.ui.theme.DividerColor
import com.djassaeco.ui.theme.TextPrimary

@Composable
fun AllDonsScreen(
    dons: List<Don>,
    onBack: () -> Unit,
    onContactDonneur: (Don) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        // Header
        Surface(color = Color.White, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
                Text("Tous les dons", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
            }
            HorizontalDivider(color = DividerColor)
        }

        if (dons.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aucun don disponible pour le moment", color = Color.Gray)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(dons) { don ->
                    DonneurCard(don = don, onClick = { onContactDonneur(don) })
                }
            }
        }
    }
}
