package com.djassaeco.ui.screens.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.R
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*
import com.djassaeco.navigation.Screen
import kotlinx.coroutines.delay
import com.djassaeco.ui.components.ArticleCard
import com.djassaeco.ui.components.ShimmerArticleCard

@Composable
fun HomeScreen(
    articles: List<Article>,
    favoriIds: List<String>,
    nonLuesCount: Int,
    onToggleFavorite: (String) -> Unit,
    onArticleClick: (String) -> Unit,
    onMsgClick: () -> Unit,
    onNotifClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    var selectedCategorie by remember { mutableStateOf(Categorie.TOUT) }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }

    val filteredArticles = remember(selectedCategorie, searchQuery, articles) {
        articles.filter { article ->
            val matchesCategory = if (selectedCategorie == Categorie.TOUT) true 
                                 else article.categorie == selectedCategorie
            val matchesSearch = if (searchQuery.isEmpty()) true 
                               else article.titre.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    LaunchedEffect(selectedCategorie) {
        isLoading = true
        delay(600)
        isLoading = false
    }

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        Surface(color = Color.White, shadowElevation = 2.dp) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.logo_app), 
                        contentDescription = null, 
                        modifier = Modifier.height(100.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BadgedBox(
                            badge = { 
                                if (nonLuesCount > 0) {
                                    Badge { Text(nonLuesCount.toString()) } 
                                }
                            }
                        ) {
                            IconButton(onClick = onNotifClick) { 
                                Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(22.dp)) 
                            }
                        }
                        
                        IconButton(onClick = onMsgClick) { 
                            Icon(Icons.AutoMirrored.Filled.Message, contentDescription = null, modifier = Modifier.size(22.dp)) 
                        }

                        IconButton(onClick = onProfileClick) { Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(22.dp)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher un article...", color = TextHint, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextHint, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Effacer", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                    shape  = RoundedCornerShape(25.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = Color(0xFFF4F4F4),
                        focusedContainerColor = Color(0xFFF4F4F4),
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = EcoGreen
                    ),
                    singleLine = true
                )
            }
        }

        Surface(color = Color.White) {
            Column(modifier = Modifier.padding(bottom = 10.dp)) {
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Catégories", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                }
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(Categorie.entries) { cat ->
                        CategorieItem(categorie = cat, selected = selectedCategorie == cat, onSelect = { selectedCategorie = cat })
                    }
                }
            }
            HorizontalDivider(color = DividerColor)
        }

        if (isLoading) {
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize()) {
                items(6) { ShimmerArticleCard(modifier = Modifier.border(0.5.dp, DividerColor)) }
            }
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize()) {
                items(filteredArticles, key = { it.id }) { article ->
                    ArticleCard(
                        article = article.copy(estFavori = favoriIds.contains(article.id)),
                        onClick = { onArticleClick(article.id) },
                        onFavoriteToggle = { onToggleFavorite(article.id) },
                        modifier = Modifier.border(0.5.dp, DividerColor)
                    )
                }
            }
        }
    }
}

@Composable
fun CategorieItem(categorie: Categorie, selected: Boolean, onSelect: () -> Unit) {
    val bgColors = mapOf(
        Categorie.TOUT             to (Color(0xFFE8F8F1) to EcoGreen),
        Categorie.VETEMENTS        to (Color(0xFFF0EEFF) to Color(0xFF7F77DD)),
        Categorie.CHAUSSURES       to (Color(0xFFFFF8E6) to Color(0xFFBA7517)),
        Categorie.LIVRES           to (Color(0xFFFFF8E6) to Color(0xFFBA7517)),
        Categorie.SCOLAIRE         to (Color(0xFFE8F8F1) to EcoGreen),
        Categorie.MOBILIER         to (Color(0xFFFDF0F8) to Color(0xFFD4537E)),
        Categorie.JOUETS           to (Color(0xFFF0EEFF) to Color(0xFF7F77DD)),
        Categorie.DECHETS_TEXTILES to (Color(0xFFFFF0EE) to Color(0xFFD85A30)),
        Categorie.RECYCLE          to (Color(0xFFE8F8F1) to EcoGreen),
    )
    val colorPair = bgColors[categorie] ?: (Color(0xFFF0F0F0) to TextTertiary)
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSelect() }) {
        Box(modifier = Modifier.size(54.dp).clip(CircleShape).background(colorPair.first).then(if (selected) Modifier.border(2.5.dp, EcoGreen, CircleShape) else Modifier), contentAlignment = Alignment.Center) {
            Text(when (categorie) {
                Categorie.TOUT -> "🔲"
                Categorie.VETEMENTS -> "👕"
                Categorie.CHAUSSURES -> "👟"
                Categorie.LIVRES -> "📚"
                Categorie.SCOLAIRE -> "🎒"
                Categorie.MOBILIER -> "🛋️"
                Categorie.JOUETS -> "🧸"
                Categorie.DECHETS_TEXTILES -> "🧵"
                Categorie.RECYCLE -> "♻️"
            }, fontSize = 22.sp)
        }
        Spacer(Modifier.height(5.dp))
        Text(text = categorie.label, fontSize = 9.sp, color = if (selected) EcoGreen else TextTertiary, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}
