package com.djassaeco.ui.screens.dons

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.djassaeco.data.model.Don
import com.djassaeco.ui.theme.*

@Composable
fun DonDetailScreen(
    don: Don,
    onBack: () -> Unit,
    onContact: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 80.dp)
        ) {
            // Image du don
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(EcoGreen.copy(alpha = 0.05f)),
                contentAlignment = Alignment.Center
            ) {
                if (don.images.isNotEmpty()) {
                    AsyncImage(
                        model = don.images.first(),
                        contentDescription = don.typeDon,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    // Image par défaut (style Vinted) si pas de photo
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CardGiftcard,
                            contentDescription = null,
                            modifier = Modifier.size(80.dp),
                            tint = EcoGreen.copy(alpha = 0.3f)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = don.typeDon,
                            fontWeight = FontWeight.Bold,
                            color = EcoGreen,
                            fontSize = 18.sp
                        )
                    }
                }
                
                // Back Button
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(16.dp)
                        .background(Color.White.copy(alpha = 0.9f), CircleShape)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
            }

            Column(modifier = Modifier.padding(20.dp)) {
                // Donor Info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(EcoGreen.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = don.donateur?.take(1)?.uppercase() ?: "D",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = EcoGreen
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = don.donateur ?: "Donneur anonyme",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                        Text("Donateur actif", fontSize = 12.sp, color = EcoGreen)
                    }
                }

                Spacer(Modifier.height(24.dp))
                HorizontalDivider(color = DividerColor)
                Spacer(Modifier.height(24.dp))

                // Donation Info
                InfoRow(Icons.Default.Category, "Type de don", don.typeDon)
                InfoRow(Icons.Default.LocationOn, "Localisation", don.localisation)
                InfoRow(Icons.Default.History, "État de l'objet", don.etat.label)
                InfoRow(Icons.Default.Event, "Disponibilité", don.disponibilite.toString())

                Spacer(Modifier.height(24.dp))
                Text("Description", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Je donne cet objet car je ne l'utilise plus. Il est en bon état et j'espère qu'il pourra servir à quelqu'un d'autre à Abidjan. N'hésitez pas à me contacter pour convenir d'un rendez-vous pour la remise.",
                    fontSize = 14.sp,
                    color = TextSecondary,
                    lineHeight = 22.sp
                )
            }
        }

        // Contact Button Fixed at bottom
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Button(
                onClick = onContact,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)
            ) {
                Icon(Icons.Default.Chat, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Contacter le donateur", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFF5F5F5)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(label, fontSize = 11.sp, color = TextTertiary)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
        }
    }
}
