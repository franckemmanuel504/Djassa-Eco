package com.djassaeco.ui.screens.dons

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.Don
import com.djassaeco.ui.theme.EcoGreen
import com.djassaeco.ui.theme.TextPrimary
import com.djassaeco.ui.theme.TextTertiary

@Composable
fun ConfirmDonScreen(don: Don?, onFinish: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.height(32.dp))

        // Icône de succès
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(RoundedCornerShape(50))
                .background(EcoGreen),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(44.dp))
        }

        Spacer(Modifier.height(24.dp))

        Text("Don enregistré !", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        Text(
            "Merci pour votre geste solidaire.\nNous vous contacterons bientôt.",
            fontSize = 14.sp, color = TextTertiary, textAlign = TextAlign.Center, lineHeight = 20.sp
        )

        Spacer(Modifier.height(32.dp))

        // --- CARTE VERTE DE RÉCAPITULATIF ---
        if (don != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(16.dp),
                color    = Color(0xFFE8F8F1), // Fond vert clair
                border   = BorderStroke(1.5.dp, Color(0xFF5DCAA5)) // Bordure verte
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EcoGreen, modifier = Modifier.size(18.dp))
                        Text("Récapitulatif de votre don", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF085041))
                    }
                    
                    Spacer(Modifier.height(16.dp))
                    
                    DonRecapRow("Donateur",    don.donateur ?: "Anonyme")
                    DonRecapRow("Téléphone",   don.telephone)
                    DonRecapRow("Localisation", don.localisation.ifBlank { "Non précisée" })
                    DonRecapRow("Type de don",  don.typeDon.ifBlank { "Non précisé" })
                    
                    // Affichage complet de la disponibilité
                    DonRecapRow("Disponibilité", don.disponibilite.toString())
                    
                    DonRecapRow("État",        don.etat.label)
                }
            }
        }

        Spacer(Modifier.height(40.dp))

        Button(
            onClick  = onFinish,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape    = RoundedCornerShape(14.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen)
        ) {
            Text("Retour à l'accueil", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun DonRecapRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 12.sp, color = Color(0xFF0F6E56))
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF085041), textAlign = TextAlign.End, modifier = Modifier.weight(1f).padding(start = 16.dp))
        }
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color = Color(0xFF9FE1CB).copy(alpha = 0.5f), thickness = 1.dp)
    }
}
