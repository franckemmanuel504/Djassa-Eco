package com.djassaeco.ui.screens.auth

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.ui.theme.EcoGreen
import com.djassaeco.ui.theme.TextPrimary
import com.djassaeco.ui.theme.TextTertiary
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider

@Composable
fun OtpScreen(
    verificationIdFromNav: String,
    onConfirmed: () -> Unit
) {
    var otp by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }
    var verificationId by remember { mutableStateOf(verificationIdFromNav) }
    val auth = FirebaseAuth.getInstance()

    // Gestion des callbacks Firebase pour l'OTP (si on renvoie le code)
    val callbacks = remember {
        object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                auth.signInWithCredential(credential)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) onConfirmed()
                    }
            }

            override fun onVerificationFailed(e: FirebaseException) {
                // Gérer l'erreur
            }

            override fun onCodeSent(
                id: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                verificationId = id
            }
        }
    }

    fun verifyOtp() {
        if (verificationId.isNotEmpty() && otp.length == 6) {
            val credential = PhoneAuthProvider.getCredential(verificationId, otp)
            auth.signInWithCredential(credential)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        onConfirmed()
                    } else {
                        // Gérer l'erreur
                    }
                }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Row(modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = { /* Retour */ }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour", tint = TextPrimary)
            }
        }

        Spacer(Modifier.height(32.dp))

        Text("Vérification OTP", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(10.dp))
        Text(
            "Un code de vérification a été envoyé au\n+225 07 00 00 00 00",
            fontSize = 13.sp, color = TextTertiary, textAlign = TextAlign.Center, lineHeight = 20.sp
        )

        Spacer(Modifier.height(36.dp))

        Box(contentAlignment = Alignment.Center) {
            BasicTextField(
                value = otp,
                onValueChange = {
                    if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                        otp = it
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier
                    .focusRequester(focusRequester)
                    .size(1.dp)
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.clickable { focusRequester.requestFocus() }
            ) {
                repeat(6) { index ->
                    val char = if (index < otp.length) otp[index].toString() else ""
                    val isFocused = index == otp.length
                    Box(
                        modifier = Modifier
                            .size(46.dp, 54.dp)
                            .border(
                                width = if (isFocused) 2.dp else 1.5.dp,
                                color = if (isFocused) EcoGreen else Color(0xFFEEEEEE),
                                shape = RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(char, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.Center) {
            Text("Vous n'avez pas reçu le code ? ", color = TextTertiary, fontSize = 12.sp)
            TextButton(onClick = { /* Logique de renvoi */ }) {
                Text("Renvoyer", color = EcoGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(32.dp))

        Button(
            onClick  = { verifyOtp() },
            enabled  = otp.length == 6,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape    = RoundedCornerShape(13.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen, disabledContainerColor = Color(0xFFCCCCCC))
        ) {
            Text("Confirmer", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onConfirmed) {
            Text("Passer l'étape (Debug) →", color = EcoGreen, fontSize = 12.sp)
        }
    }
}
