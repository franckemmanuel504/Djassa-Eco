package com.djassaeco.ui.screens.profile

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.djassaeco.R
import com.djassaeco.data.model.Article
import com.djassaeco.ui.theme.*

@Composable
fun MesArticlesScreen(
    articles: List<Article>,
    onBack: () -> Unit,
    onPublish: () -> Unit
) {
    val articlesEnVente = articles
    val articlesVendus  = emptyList<Article>()

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        Surface(color = Color.White) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
                Text("Mes articles", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            HorizontalDivider(color = DividerColor)
        }

        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SectionHeader("En vente (${articlesEnVente.size})")
            if (articlesEnVente.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("Aucun article en vente", color = TextTertiary, fontSize = 14.sp)
                }
            } else {
                articlesEnVente.forEach { art -> MyArticleItem(art, vendu = false) }
            }

            if (articlesVendus.isNotEmpty()) {
                SectionHeader("Vendus (${articlesVendus.size})")
                articlesVendus.forEach { art -> MyArticleItem(art, vendu = true) }
            }
        }

        Surface(color = Color.White, shadowElevation = 8.dp) {
            Button(
                onClick  = onPublish,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).height(50.dp),
                shape    = RoundedCornerShape(14.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Ajouter un article", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Box(modifier = Modifier.fillMaxWidth().background(BackgroundLight).padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(text.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary, letterSpacing = .5.sp)
    }
}

@Composable
private fun MyArticleItem(article: Article, vendu: Boolean) {
    Surface(color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Recommendation 1: Utilisation de l'image centralisée
            if (article.images.isNotEmpty()) {
                AsyncImage(
                    model = article.images.first(),
                    contentDescription = null,
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painter = painterResource(id = article.coverImageRes ?: R.drawable.pull_cardina),
                    contentDescription = null,
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            // Infos
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "${article.prix} F CFA",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (vendu) TextTertiary else EcoGreen
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    article.etat.label,
                    fontSize = 12.sp,
                    color = TextTertiary
                )
            }

            // Actions
            Column(horizontalAlignment = Alignment.End) {
                // Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (vendu) Color(0xFFF0F0F0) else Color(0xFFE8F8F1)
                ) {
                    Text(
                        if (vendu) "Vendu" else "En ligne",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (vendu) TextTertiary else EcoGreen,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                if (!vendu) {
                    Spacer(Modifier.height(8.dp))
                    // Boutons regroupés
                    Row(
                        modifier = Modifier
                            .border(1.dp, Color(0xFFEEEEEE), RoundedCornerShape(10.dp))
                            .height(36.dp)
                            .width(80.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.weight(1f).fillMaxHeight().clickable { },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = EcoGreen, modifier = Modifier.size(16.dp))
                        }
                        Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color(0xFFEEEEEE)))
                        Box(
                            modifier = Modifier.weight(1f).fillMaxHeight().clickable { },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = DangerRed, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
        HorizontalDivider(color = DividerColor, modifier = Modifier.padding(start = 92.dp))
    }
}
