package com.djassaeco.ui.screens.dons

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonFormScreen(
    typeDestinataire: String,
    onBack: () -> Unit,
    onSubmit: (Don) -> Unit
) {
    val context = LocalContext.current
    var nom     by remember { mutableStateOf("") }
    var tel     by remember { mutableStateOf("") }
    var loc     by remember { mutableStateOf("") }
    var typeDon by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    // Gestion des images
    var selectedImages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var showPhotoOptions by remember { mutableStateOf(false) }
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }

    // Disponibilité
    var dispoMode   by remember { mutableStateOf("jours") }
    var selectedJour by remember { mutableStateOf("Lundi 14 Avr") }
    var heureDebut  by remember { mutableStateOf("09:00") }
    var heureFin    by remember { mutableStateOf("13:00") }
    var periode     by remember { mutableStateOf(Periode.MATIN) }

    // État
    var selectedEtat by remember { mutableStateOf(EtatArticle.BON_ETAT) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { selectedImages = selectedImages + it }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            tempCameraUri?.let { selectedImages = selectedImages + it }
        }
    }

    fun launchCamera() {
        val directory = File(context.cacheDir, "images")
        if (!directory.exists()) directory.mkdirs()
        val file = File(directory, "don_camera_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(context, "com.djassaeco.fileprovider", file)
        tempCameraUri = uri
        cameraLauncher.launch(uri)
    }

    val sheetState = rememberModalBottomSheetState()

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        // Header
        Surface(color = Color.White) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
                Text(if (typeDestinataire == "ASSOCIATION") "Don à une association" else "Enregistrer un don", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ── Photos ──
            DonPubCard(title = "Photos de l'objet") {
                if (selectedImages.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(2.dp, EcoGreen, RoundedCornerShape(16.dp))
                            .background(Color(0xFFF0FDF8))
                            .clickable { showPhotoOptions = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PhotoCamera, null, tint = EcoGreen, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Ajouter des photos", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(selectedImages) { uri ->
                            Box(modifier = Modifier.size(100.dp)) {
                                AsyncImage(
                                    model = uri,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                IconButton(
                                    onClick = { selectedImages = selectedImages.filter { it != uri } },
                                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(24.dp).background(Color.Black.copy(0.5f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                        if (selectedImages.size < 5) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .border(1.5.dp, BorderColor, RoundedCornerShape(12.dp))
                                        .background(Color(0xFFFAFAFA))
                                        .clickable { showPhotoOptions = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Add, null, tint = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }

            // ── Informations ──
            DonPubCard(title = "Informations") {
                DonPubField("Type de don (Titre)", typeDon, { typeDon = it }, "Vêtements, Chaussures...")
                Spacer(Modifier.height(12.dp))
                DonPubField("Localisation", loc, { loc = it }, "ex: Abidjan / Cocody")
                Spacer(Modifier.height(12.dp))
                DonPubField("Téléphone *", tel, { tel = it }, "Obligatoire")
            }

            // ── Disponibilité ──
            DonPubCard(title = "Disponibilité") {
                Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color(0xFFF0F0F0)).padding(3.dp)) {
                    listOf("jours" to "Jours", "heures" to "Heures").forEach { (key, label) ->
                        Surface(
                            onClick  = { dispoMode = key },
                            modifier = Modifier.weight(1f),
                            shape    = RoundedCornerShape(11.dp),
                            color    = if (dispoMode == key) Color.White else Color.Transparent
                        ) {
                            Text(label, modifier = Modifier.padding(vertical = 9.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (dispoMode == key) EcoGreen else TextTertiary)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                if (dispoMode == "jours") {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        val jours = listOf(Triple("LUN","14","Avr"), Triple("MAR","15","Avr"), Triple("MER","16","Avr"), Triple("JEU","17","Avr"), Triple("VEN","18","Avr"), Triple("SAM","19","Avr"), Triple("DIM","20","Avr"))
                        jours.forEach { (nom2, num, mois) ->
                            val label = "$nom2 $num $mois"
                            val sel = selectedJour == label
                            Surface(
                                onClick = { selectedJour = label },
                                shape   = RoundedCornerShape(13.dp),
                                color   = if (sel) Color(0xFFE8F8F1) else Color(0xFFFAFAFA),
                                border  = BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) EcoGreen else BorderColor)
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(nom2, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (sel) EcoGreen else TextTertiary)
                                    Text(num, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (sel) EcoGreen else TextPrimary)
                                    Text(mois, fontSize = 8.sp, color = if (sel) EcoGreen else TextTertiary)
                                }
                            }
                        }
                    }
                } else {
                    // Sélection des heures
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = heureDebut,
                            onValueChange = { heureDebut = it },
                            modifier = Modifier.weight(1f),
                            label = { Text("Début", fontSize = 10.sp) },
                            placeholder = { Text("09:00") },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = BorderColor, focusedBorderColor = EcoGreen)
                        )
                        Text("-", fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = heureFin,
                            onValueChange = { heureFin = it },
                            modifier = Modifier.weight(1f),
                            label = { Text("Fin", fontSize = 10.sp) },
                            placeholder = { Text("17:00") },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = BorderColor, focusedBorderColor = EcoGreen)
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Periode.entries.forEach { p ->
                            val sel = periode == p
                            FilterChip(
                                selected = sel,
                                onClick = { periode = p },
                                label = { Text(p.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = EcoGreen, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }
            }

            // ── État ──
            DonPubCard(title = "État de l'objet") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(EtatArticle.NEUF, EtatArticle.BON_ETAT, EtatArticle.TRES_BON_ETAT).forEach { etat ->
                        val sel = selectedEtat == etat
                        Surface(
                            onClick = { selectedEtat = etat },
                            modifier = Modifier.weight(1f),
                            shape    = RoundedCornerShape(10.dp),
                            color    = if (sel) Color(0xFFF0FDF8) else Color.White,
                            border   = BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) EcoGreen else BorderColor)
                        ) {
                            Text(
                                text = etat.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (sel) EcoGreen else TextTertiary,
                                modifier = Modifier.padding(vertical = 11.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }

            // ── Description ──
            DonPubCard(title = "Description") {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text("Décrivez l'objet (taille, défauts...)", color = TextHint, fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth().height(90.dp),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = BorderColor, focusedBorderColor = EcoGreen, unfocusedContainerColor = Color(0xFFFAFAFA))
                )
            }
        }

        Surface(color = Color.White, shadowElevation = 8.dp) {
            Button(
                onClick  = { 
                    val dispo = if (dispoMode == "jours")
                        Disponibilite.ParJour(selectedJour.split(" ")[0], selectedJour.split(" ")[1], selectedJour.split(" ").getOrElse(2) { "Avr" })
                    else
                        Disponibilite.ParHeure(heureDebut, heureFin, periode)
                    onSubmit(Don(donateur = nom, telephone = tel, localisation = loc, typeDon = typeDon, disponibilite = dispo, etat = selectedEtat, images = selectedImages, typeDestinataire = typeDestinataire))
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).height(52.dp),
                shape    = RoundedCornerShape(14.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen)
            ) {
                Text("S'enregistrer", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }

        if (showPhotoOptions) {
            ModalBottomSheet(
                onDismissRequest = { showPhotoOptions = false },
                sheetState = sheetState,
                containerColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp, start = 16.dp, end = 16.dp, top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("Ajouter une photo", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    
                    ListItem(
                        headlineContent = { Text("Prendre une photo", fontSize = 16.sp) },
                        leadingContent = { Icon(Icons.Default.PhotoCamera, null, tint = EcoGreen) },
                        modifier = Modifier.clickable { 
                            launchCamera()
                            showPhotoOptions = false
                        }
                    )

                    ListItem(
                        headlineContent = { Text("Choisir depuis la galerie", fontSize = 16.sp) },
                        leadingContent = { Icon(Icons.Default.Image, null, tint = EcoGreen) },
                        modifier = Modifier.clickable { 
                            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            showPhotoOptions = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DonPubCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary, letterSpacing = .5.sp)
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun DonPubField(label: String, value: String, onValueChange: (String) -> Unit, placeholder: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary, letterSpacing = .5.sp)
        OutlinedTextField(
            value = value, onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = TextHint, fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(12.dp),
            colors   = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = BorderColor, focusedBorderColor = EcoGreen, unfocusedContainerColor = Color(0xFFFAFAFA)),
            singleLine = true
        )
    }
}
