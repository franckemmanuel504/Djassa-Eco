package com.djassaeco.ui.screens.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.Article
import com.djassaeco.ui.theme.*

@Composable
fun NegoScreen(
    article: Article,
    onBack: () -> Unit,
    onSend: (Int) -> Unit
) {
    var offerPrice by remember { mutableIntStateOf((article.prix * 0.8).toInt()) }

    val savings = article.prix - offerPrice
    val savingsPct = if (article.prix > 0) ((savings.toFloat() / article.prix) * 100).toInt() else 0

    val quickOffers = listOf(
        article.prix / 2,
        (article.prix * 0.67).toInt(),
        (article.prix * 0.80).toInt(),
        (article.prix * 0.90).toInt()
    )

    Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = .5f))) {
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            color = Color.White
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) {
                // Handle
                Box(modifier = Modifier.width(40.dp).height(4.dp).background(Color(0xFFE0E0E0), RoundedCornerShape(2.dp)).align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(20.dp))

                Text("Faire une offre", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Row { 
                    Text("Prix affiché : ", fontSize = 12.sp, color = TextTertiary)
                    Text("${article.prix} F CFA", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EcoGreen) 
                }
                Spacer(Modifier.height(16.dp))

                // Récap
                Surface(shape = RoundedCornerShape(13.dp), color = Color(0xFFF8F8F8)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        RecapRow("Prix affiché", "${article.prix} F", TextPrimary)
                        RecapRow("Votre offre", "$offerPrice F", AccentOrange)
                        RecapRow("Économie", "−$savings F ($savingsPct%)", EcoGreen)
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Contrôle +/-
                Text("Votre offre (F CFA)".uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF888888))
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StepButton("-") { if (offerPrice - 100 >= article.prix / 3) offerPrice -= 100 }
                    OutlinedTextField(
                        value = offerPrice.toString(),
                        onValueChange = { v -> v.toIntOrNull()?.let { offerPrice = it.coerceIn(article.prix / 3, article.prix) } },
                        modifier = Modifier.weight(1f),
                        textStyle = LocalTextStyle.current.copy(fontSize = 22.sp, fontWeight = FontWeight.Bold, color = EcoGreen, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                        shape = RoundedCornerShape(13.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EcoGreen, unfocusedBorderColor = EcoGreen),
                        singleLine = true
                    )
                    StepButton("+") { if (offerPrice + 100 <= article.prix) offerPrice += 100 }
                }

                Spacer(Modifier.height(14.dp))

                // Offres rapides
                Text("Offres rapides".uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF888888))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    val labels = listOf("-50%", "-33%", "-20%", "-10%")
                    quickOffers.forEachIndexed { i, price ->
                        val sel = offerPrice == price
                        Surface(
                            modifier = Modifier.weight(1f).clickable { offerPrice = price },
                            shape = RoundedCornerShape(11.dp),
                            color = if (sel) Color(0xFFE8F8F1) else Color(0xFFF8F8F8),
                            border = if (sel) androidx.compose.foundation.BorderStroke(1.5.dp, EcoGreen) else androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFEEEEEE))
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 9.dp)
                            ) {
                                Text("$price F", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (sel) EcoGreen else TextSecondary)
                                Text(labels[i], fontSize = 9.sp, color = if (sel) Color(0xFF0D7A50) else TextTertiary)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("Le vendeur recevra une notification et pourra accepter, refuser ou faire une contre-offre.", fontSize = 10.sp, color = TextTertiary, textAlign = androidx.compose.ui.text.style.TextAlign.Center, lineHeight = 15.sp, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = { onSend(offerPrice) }, 
                    modifier = Modifier.fillMaxWidth().height(50.dp), 
                    shape = RoundedCornerShape(14.dp), 
                    colors = ButtonDefaults.buttonColors(containerColor = AccentOrange)
                ) {
                    Text("Envoyer l'offre — $offerPrice F", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                    Text("Annuler", color = TextTertiary, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun RecapRow(label: String, value: String, valueColor: Color) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 11.sp, color = TextTertiary)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = valueColor)
    }
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.size(40.dp),
        shape = RoundedCornerShape(50),
        color = Color(0xFFF8F8F8),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFEEEEEE))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, fontSize = 22.sp, color = Color(0xFF444444), lineHeight = 22.sp)
        }
    }
}
