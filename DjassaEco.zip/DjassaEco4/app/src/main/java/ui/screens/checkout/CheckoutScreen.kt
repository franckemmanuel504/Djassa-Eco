package com.djassaeco.ui.screens.checkout

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.R
import com.djassaeco.data.model.Article
import com.djassaeco.data.model.ModeLivraison
import com.djassaeco.ui.theme.*

@Composable
fun CheckoutScreen(
    article: Article,
    userPhone: String,
    deliveryResult: DeliveryResult? = null,
    onBack: () -> Unit,
    onOpenMap: () -> Unit,
    onPay: (String, String, ModeLivraison, String) -> Unit
) {
    var useDelivery      by remember { mutableStateOf(deliveryResult != null) }
    var selectedPaiement by remember { mutableStateOf("om") }
    var phoneNumber      by remember { mutableStateOf(userPhone) }

    // Synchroniser quand le résultat de la carte arrive
    LaunchedEffect(deliveryResult) {
        if (deliveryResult != null) useDelivery = true
    }

    val deliveryFee = if (useDelivery && deliveryResult != null) deliveryResult.deliveryFee else 0
    val total       = article.prix + deliveryFee

    val payNames = mapOf(
        "om"   to "Orange Money",
        "wv"   to "Wave",
        "mt"   to "MTN Mobile Money",
        "cash" to "Paiement à la livraison"
    )

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {

        // ── Header ────────────────────────────────────────────────────────────
        Surface(color = Color.White) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, "Retour")
                }
                Text("Finaliser l'achat", fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    modifier = Modifier.weight(1f))
                Text("$total F", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EcoGreen)
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // ── Livraison ─────────────────────────────────────────────────────
            CheckoutCard(title = "Mode de livraison") {

                // Option Retrait
                LivraisonOption(
                    label = "Retrait chez le vendeur",
                    subtitle = "${article.localisation} · Disponible maintenant",
                    price = "Gratuit", priceColor = EcoGreen,
                    icon = Icons.Default.Person,
                    iconBg = Color(0xFFE8F8F1), iconTint = EcoGreen,
                    selected = !useDelivery,
                    onClick = { useDelivery = false }
                )

                Spacer(Modifier.height(10.dp))

                // Option Livraison carte
                Surface(
                    onClick = onOpenMap,
                    shape = RoundedCornerShape(12.dp),
                    color = if (useDelivery) Color(0xFFF0FDF8) else Color.White,
                    border = BorderStroke(
                        if (useDelivery) 1.5.dp else 1.dp,
                        if (useDelivery) EcoGreen else BorderColor
                    )
                ) {
                    Column(modifier = Modifier.padding(13.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(11.dp)
                        ) {
                            RadioBtn(useDelivery)
                            Box(
                                modifier = Modifier.size(36.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(AccentBlueLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.LocalShipping, null, tint = AccentBlue,
                                    modifier = Modifier.size(18.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Livraison à domicile",
                                    fontWeight = FontWeight.SemiBold, fontSize = 12.sp,
                                    color = TextPrimary)
                                if (useDelivery && deliveryResult != null) {
                                    Text(
                                        "~${deliveryResult.estimatedMinutes} min · ${deliveryResult.mode.label}",
                                        fontSize = 10.sp, color = EcoGreen,
                                        modifier = Modifier.padding(top = 1.dp)
                                    )
                                } else {
                                    Text("Choisir l'adresse sur la carte",
                                        fontSize = 10.sp, color = TextTertiary,
                                        modifier = Modifier.padding(top = 1.dp))
                                }
                            }
                            if (useDelivery && deliveryResult != null) {
                                Text("+${deliveryResult.deliveryFee} F",
                                    fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                    color = TextSecondary)
                            } else {
                                Icon(Icons.Default.ChevronRight, null, tint = TextTertiary,
                                    modifier = Modifier.size(18.dp))
                            }
                        }

                        // Détail adresse sélectionnée
                        if (useDelivery && deliveryResult != null) {
                            Spacer(Modifier.height(10.dp))
                            Surface(shape = RoundedCornerShape(10.dp), color = BackgroundLight) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.LocationOn, null, tint = EcoGreen,
                                        modifier = Modifier.size(14.dp))
                                    Text(deliveryResult.address, fontSize = 11.sp,
                                        color = TextSecondary, modifier = Modifier.weight(1f))
                                    TextButton(
                                        onClick = onOpenMap,
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("Modifier", fontSize = 11.sp, color = AccentBlue)
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                DeliveryInfoChip(Icons.Default.Straighten,
                                    "~${String.format("%.1f", deliveryResult.distanceKm)} km")
                                DeliveryInfoChip(Icons.Default.AccessTime,
                                    "~${deliveryResult.estimatedMinutes} min")
                            }
                        }
                    }
                }
            }

            // ── Paiement ──────────────────────────────────────────────────────
            CheckoutCard(title = "Mode de paiement") {
                PaiementOption(
                    id = "om", name = "Orange Money", subtitle = userPhone.ifBlank { "Numéro non renseigné" },
                    logoColor = Color(0xFFFF6600), selectedId = selectedPaiement,
                    logoRes = R.drawable.om
                ) { selectedPaiement = it }
                
                Spacer(Modifier.height(9.dp))
                
                PaiementOption(
                    id = "wv", name = "Wave", subtitle = "Zéro frais",
                    logoColor = Color(0xFF0099FF), selectedId = selectedPaiement,
                    logoRes = R.drawable.wave
                ) { selectedPaiement = it }
                
                Spacer(Modifier.height(9.dp))
                
                PaiementOption(
                    id = "mt", name = "MTN Mobile Money", subtitle = "Paiement sécurisé",
                    logoColor = Color(0xFFFFCC00), selectedId = selectedPaiement, textColor = Color(0xFF333333),
                    logoRes = R.drawable.mtn
                ) { selectedPaiement = it }

                if (selectedPaiement != "cash") {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = phoneNumber, onValueChange = { phoneNumber = it },
                        label = { Text("Numéro Mobile Money", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EcoGreen),
                        placeholder = { Text("07 00 00 00 00") }
                    )
                }

                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = DividerColor)
                Spacer(Modifier.height(14.dp))
                PaiementOption(
                    id = "cash", name = "Payer à la livraison",
                    subtitle = "Espèces acceptées à la réception",
                    logoColor = EcoGreen, selectedId = selectedPaiement,
                    icon = Icons.Default.Payments
                ) { selectedPaiement = it }
            }

            // ── Résumé ────────────────────────────────────────────────────────
            Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                Column(modifier = Modifier.padding(16.dp)) {
                    TotalRow("Article", "${article.prix} F CFA", TextPrimary)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 7.dp), color = DividerColor)
                    TotalRow(
                        "Livraison",
                        if (deliveryFee == 0) "Gratuit" else "+$deliveryFee F",
                        if (deliveryFee == 0) EcoGreen else TextPrimary
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 7.dp), color = DividerColor)
                    TotalRow("Paiement via", payNames[selectedPaiement] ?: "", TextPrimary)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 7.dp), color = DividerColor)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                        Text("$total F", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = EcoGreen)
                    }
                }
            }
        }

        // ── Bouton Payer ──────────────────────────────────────────────────────
        Surface(color = Color.White, shadowElevation = 8.dp) {
            val canPay = (selectedPaiement == "cash" || phoneNumber.length >= 8)
            Button(
                onClick = {
                    val mode    = if (!useDelivery || deliveryResult == null) ModeLivraison.Retrait
                                  else when (deliveryResult.mode) {
                                      DeliveryMode.STANDARD -> ModeLivraison.Djassa
                                      DeliveryMode.EXPRESS  -> ModeLivraison.ExpressMoto
                                  }
                    val address = if (useDelivery && deliveryResult != null) deliveryResult.address else ""
                    onPay(selectedPaiement, phoneNumber, mode, address)
                },
                enabled  = canPay,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .height(52.dp),
                shape  = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)
            ) {
                val btnText = if (selectedPaiement == "cash") "Confirmer la commande"
                              else "Payer maintenant — $total F"
                Text(btnText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun CheckoutCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary, letterSpacing = .5.sp)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun LivraisonOption(
    label: String, subtitle: String, price: String, priceColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color, iconTint: Color, selected: Boolean, onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape   = RoundedCornerShape(12.dp),
        color   = if (selected) Color(0xFFF0FDF8) else Color.White,
        border  = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) EcoGreen else BorderColor)
    ) {
        Row(modifier = Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            RadioBtn(selected)
            Box(modifier = Modifier.size(36.dp).clip(RoundedCornerShape(9.dp)).background(iconBg), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = TextPrimary)
                Text(subtitle, fontSize = 10.sp, color = TextTertiary, modifier = Modifier.padding(top = 1.dp))
            }
            Text(price, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = priceColor)
        }
    }
}

@Composable
fun PaiementOption(
    id: String, name: String, subtitle: String, logoColor: Color,
    selectedId: String, textColor: Color = Color.White, 
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    logoRes: Int? = null,
    onSelect: (String) -> Unit
) {
    val sel = id == selectedId
    Surface(
        onClick = { onSelect(id) },
        shape   = RoundedCornerShape(12.dp),
        color   = if (sel) Color(0xFFF0FDF8) else Color.White,
        border  = BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) EcoGreen else BorderColor)
    ) {
        Row(modifier = Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            RadioBtn(sel)
            Box(modifier = Modifier.width(44.dp).height(28.dp).clip(RoundedCornerShape(8.dp)).background(logoColor), contentAlignment = Alignment.Center) {
                if (logoRes != null) {
                    Image(
                        painter = painterResource(id = logoRes),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else if (icon != null) {
                    Icon(icon, contentDescription = null, tint = textColor, modifier = Modifier.size(16.dp))
                } else {
                    Text(id.uppercase(), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = textColor)
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = TextPrimary)
                Text(subtitle, fontSize = 10.sp, color = TextTertiary, modifier = Modifier.padding(top = 1.dp))
            }
        }
    }
}

@Composable
fun RadioBtn(selected: Boolean) {
    Box(
        modifier = Modifier.size(19.dp).clip(RoundedCornerShape(50))
            .background(if (selected) EcoGreen else Color.Transparent)
            .border(if (selected) 0.dp else 1.5.dp, if (selected) EcoGreen else BorderColor, RoundedCornerShape(50)),
        contentAlignment = Alignment.Center
    ) {
        if (selected) Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Color.White))
    }
}

@Composable
fun TotalRow(label: String, value: String, valueColor: Color) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 11.sp, color = TextTertiary)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = valueColor)
    }
}

@Composable
fun DeliveryInfoChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Surface(shape = RoundedCornerShape(8.dp), color = EcoGreenLight) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, null, tint = EcoGreen, modifier = Modifier.size(12.dp))
            Text(text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = EcoGreen)
        }
    }
}
