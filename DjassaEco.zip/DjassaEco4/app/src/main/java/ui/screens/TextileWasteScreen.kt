package com.djassaeco.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.R
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*

@Composable
fun TextileWasteScreen(
    articles: List<Article>,
    onBack: () -> Unit,
    onArticleClick: (String) -> Unit,
    onContactClick: (Article) -> Unit
) {
    val wastes = articles.filter { it.typeAnnonce == TypeAnnonce.DECHET_TEXTILE }

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {
        // Header
        Surface(color = Color.White, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
                Text("Déchets Textiles", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }

        if (wastes.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aucune annonce de déchets textiles pour le moment.", color = TextTertiary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(wastes) { waste ->
                    WasteItem(waste, onClick = { onArticleClick(waste.firestoreId) }, onContact = { onContactClick(waste) })
                }
            }
        }
    }
}

@Composable
fun WasteItem(waste: Article, onClick: () -> Unit, onContact: () -> Unit) {
    // Logique d'image identique
    val imageRes = when {
        waste.titre.contains("textille", ignoreCase = true) -> R.drawable.textille
        waste.titre.contains("textile2", ignoreCase = true) -> R.drawable.textile2
        else -> R.drawable.textille
    }

    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column {
            Box(modifier = Modifier.fillMaxWidth().height(180.dp)) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = EcoGreen
                ) {
                    Text(
                        "${waste.quantiteKg ?: 0} kg",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Text(waste.titre, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = TextTertiary, modifier = Modifier.size(14.dp))
                    Text(waste.localisation, fontSize = 12.sp, color = TextTertiary)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    waste.description,
                    fontSize = 13.sp,
                    color = TextSecondary,
                    maxLines = 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                
                Spacer(Modifier.height(12.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = CircleShape, color = Color(waste.couleurVendeur).copy(0.1f)) {
                        Text(
                            waste.initiales,
                            modifier = Modifier.padding(8.dp),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(waste.couleurVendeur)
                        )
                    }
                    Text(waste.vendeur, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                    Spacer(Modifier.weight(1f))
                    Button(
                        onClick = onContact,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EcoGreen),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("Contacter", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
