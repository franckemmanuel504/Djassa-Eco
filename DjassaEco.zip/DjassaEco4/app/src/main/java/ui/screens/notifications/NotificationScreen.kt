package com.djassaeco.ui.screens.notifications

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.notifications.DjassaNotification
import com.djassaeco.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

// ─────────────────────────────────────────────────────────────────
//  ÉCRAN NOTIFICATIONS
// ─────────────────────────────────────────────────────────────────

@Composable
fun NotificationScreen(
    notifications: List<DjassaNotification>,
    onBack: () -> Unit,
    onToutMarquerLu: () -> Unit,
    onNotifClick: (DjassaNotification) -> Unit
) {
    val nonLues = notifications.count { !it.lue }

    Scaffold(
        topBar = {
            Surface(color = Color.White, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                    Text(
                        "Notifications",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (nonLues > 0) {
                        TextButton(onClick = onToutMarquerLu) {
                            Text("Tout lire", fontSize = 12.sp, color = EcoGreen, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (notifications.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        Modifier.size(80.dp).clip(CircleShape).background(Color(0xFFF5F5F5)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.NotificationsNone, null, tint = Color(0xFFCCCCCC), modifier = Modifier.size(40.dp))
                    }
                    Text("Aucune notification", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = TextPrimary)
                    Text("Vous serez notifié des messages,\noffres et paiements.", fontSize = 13.sp, color = TextTertiary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().background(BackgroundLight),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            val groupees = grouper(notifications)

            groupees.forEach { (groupe, notifs) ->
                item {
                    Text(
                        groupe,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextTertiary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
                items(notifs, key = { it.id }) { notif ->
                    NotifCard(notif = notif, onClick = { onNotifClick(notif) })
                    Spacer(Modifier.height(2.dp))
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun NotifCard(notif: DjassaNotification, onClick: () -> Unit) {
    val config = notifConfig(notif.type)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        color = if (!notif.lue) Color(0xFFF0FDF8) else Color.White
    ) {
        Column {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(config.couleur.copy(.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(config.icone, null, tint = config.couleur, modifier = Modifier.size(22.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            notif.titre,
                            fontWeight = if (!notif.lue) FontWeight.Bold else FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            formaterDate(notif.createdAt),
                            fontSize = 10.sp,
                            color = TextTertiary
                        )
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        notif.corps,
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp,
                        maxLines = 2,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }

                if (!notif.lue) {
                    Box(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(EcoGreen)
                    )
                }
            }
            HorizontalDivider(color = Color(0xFFF0F0F0))
        }
    }
}

@Composable
fun BadgeNotif(count: Int, content: @Composable () -> Unit) {
    Box {
        content()
        if (count > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 4.dp, y = (-4).dp)
                    .size(if (count > 9) 20.dp else 16.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEF4444)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (count > 99) "99+" else count.toString(),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
            }
        }
    }
}

private data class NotifConfig(val icone: ImageVector, val couleur: Color)

private fun notifConfig(type: String): NotifConfig = when (type) {
    "MESSAGE"        -> NotifConfig(Icons.AutoMirrored.Filled.Chat, Color(0xFF2563EB))
    "OFFRE"          -> NotifConfig(Icons.Default.LocalOffer,       Color(0xFFD97706))
    "OFFRE_ACCEPTEE" -> NotifConfig(Icons.Default.CheckCircle,      Color(0xFF16A34A))
    "PAIEMENT"       -> NotifConfig(Icons.Default.AccountBalanceWallet, Color(0xFF7C3AED))
    "ARTICLE_VENDU"  -> NotifConfig(Icons.Default.Storefront,       Color(0xFF16A34A))
    "LIVRAISON"      -> NotifConfig(Icons.Default.LocalShipping,    Color(0xFF0891B2))
    "DON_CONFIRME"   -> NotifConfig(Icons.Default.Favorite,         Color(0xFFE11D48))
    "CERTIFICATION"  -> NotifConfig(Icons.Default.Verified,         Color(0xFF1DB97A))
    "NOUVEAU_FAVORI" -> NotifConfig(Icons.Default.FavoriteBorder,   Color(0xFFDB2777))
    else             -> NotifConfig(Icons.Default.Notifications,    Color(0xFF6B7280))
}

private fun formaterDate(timestamp: com.google.firebase.Timestamp): String {
    val maintenant = System.currentTimeMillis()
    val diff = maintenant - timestamp.toDate().time
    val minutes = diff / 60_000
    val heures  = diff / 3_600_000
    val jours   = diff / 86_400_000
    return when {
        minutes < 1  -> "À l'instant"
        minutes < 60 -> "Il y a $minutes min"
        heures  < 24 -> "Il y a $heures h"
        jours   < 7  -> "Il y a $jours j"
        else         -> SimpleDateFormat("dd MMM", Locale.FRENCH).format(timestamp.toDate())
    }
}

private fun grouper(notifs: List<DjassaNotification>): Map<String, List<DjassaNotification>> {
    val maintenant = System.currentTimeMillis()
    return notifs.groupBy { notif ->
        val diff = maintenant - notif.createdAt.toDate().time
        when {
            diff < 86_400_000L  -> "Aujourd'hui"
            diff < 604_800_000L -> "Cette semaine"
            else                -> "Plus anciens"
        }
    }
}
