package com.djassaeco.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.djassaeco.ui.theme.DjassaTypography

val CustomLightColorScheme = lightColorScheme(
    primary          = EcoGreen,
    onPrimary        = Color.White,
    primaryContainer = EcoGreenLight,
    onPrimaryContainer = EcoGreenDark,
    secondary        = AccentOrange,
    onSecondary      = Color.White,
    background       = BackgroundLight,
    surface          = BackgroundWhite,
    onBackground     = TextPrimary,
    onSurface        = TextPrimary,
    outline          = BorderColor,
    error            = DangerRed,
)

@Composable
fun DjassaEcoAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CustomLightColorScheme,
        typography  = DjassaTypography,
        content     = content
    )
}
