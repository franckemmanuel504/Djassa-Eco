package com.djassaeco.ui.theme

import androidx.compose.ui.graphics.Color

// ── Couleurs principales Djassa Eco ──────────────────────────────────────
val EcoGreen        = Color(0xFF1DB97A)   // Vert principal
val EcoGreenLight   = Color(0xFFE8F8F1)   // Fond vert clair
val EcoGreenDark    = Color(0xFF085041)   // Vert foncé texte

val AccentOrange    = Color(0xFFE67E00)   // Orange (négociation)
val AccentOrangeLight = Color(0xFFFFF8E6) // Fond orange clair
val AccentYellow    = Color(0xFFFFD600)   // Jaune (logo accent)

val AccentBlue      = Color(0xFF378ADD)   // Bleu (badge certifié)
val AccentBlueLight = Color(0xFFE8F2FF)

val DangerRed       = Color(0xFFFF4757)   // Rouge (déconnexion, erreur)

// ── Neutres ──────────────────────────────────────────────────────────────
val BackgroundWhite = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF5F5F5)
val BackgroundCard  = Color(0xFFF8F8F8)

val TextPrimary     = Color(0xFF1A1A1A)
val TextSecondary   = Color(0xFF555555)
val TextTertiary    = Color(0xFF888888)
val TextHint        = Color(0xFFBBBBBB)

val DividerColor    = Color(0xFFF0F0F0)
val BorderColor     = Color(0xFFEEEEEE)

// ── Badges états articles ─────────────────────────────────────────────────
val ConditionNewBg      = Color(0xFFE8F8F1)
val ConditionNewText    = Color(0xFF0D7A50)
val ConditionGoodBg     = Color(0xFFFFF8E6)
val ConditionGoodText   = Color(0xFFB07D00)