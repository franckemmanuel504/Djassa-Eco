package com.djassaeco.ui.viewmodels

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.djassaeco.data.FirestoreService
import com.djassaeco.data.model.*
import com.djassaeco.notifications.DjassaNotification
import com.djassaeco.notifications.NotificationService
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val firestoreService = FirestoreService()
    private val notificationService = NotificationService()
    private val auth = FirebaseAuth.getInstance()

    var currentUserProfile by mutableStateOf<UserProfile?>(null)
        private set

    var isLoading by mutableStateOf(true)
        private set

    val notifications = mutableStateListOf<DjassaNotification>()
    var nonLuesCount by mutableStateOf(0)
        private set

    val articles = mutableStateListOf<Article>()
    val mesArticles = mutableStateListOf<Article>()
    val favoriIds = mutableStateListOf<String>()
    
    val donsDisponibles = mutableStateListOf<Don>()
    val mesDons = mutableStateListOf<Don>()
    
    val conversations = mutableStateListOf<ConversationMetadata>()

    val telephonePaiement: String
        get() = currentUserProfile?.telephone ?: ""

    init {
        loadUserThenData()
    }

    private fun loadUserThenData() {
        viewModelScope.launch {
            // Changement ici : On débloque l'UI immédiatement pour éviter l'écran figé au logo
            isLoading = false

            currentUserProfile = firestoreService.getCurrentUserProfile()

            currentUserProfile?.let { profile ->
                launch {
                    notificationService.getNotificationsFlow(profile.id).collectLatest {
                        notifications.clear()
                        notifications.addAll(it)
                    }
                }
                
                launch {
                    notificationService.getNonLuesFlow(profile.id).collectLatest {
                        nonLuesCount = it
                    }
                }

                launch {
                    notificationService.enregistrerToken(profile.id)
                }

                launch {
                    firestoreService.getMesDonsFlow(profile.id).collect { firestoreMesDons ->
                        mesDons.clear()
                        mesDons.addAll(firestoreMesDons)
                    }
                }

                launch {
                    firestoreService.getConversationsFlow(profile.id).collect {
                        conversations.clear()
                        conversations.addAll(it)
                    }
                }
            }

            launch {
                firestoreService.getArticlesFlow().collect { firestoreArticles ->
                    articles.clear()
                    articles.addAll(firestoreArticles)
                    
                    mesArticles.clear()
                    currentUserProfile?.let { profile ->
                        mesArticles.addAll(firestoreArticles.filter { it.vendeurId == profile.id })
                    }
                }
            }

            launch {
                firestoreService.getDonsFlow().collect { firestoreDons ->
                    donsDisponibles.clear()
                    donsDisponibles.addAll(firestoreDons)
                }
            }
        }
    }

    fun marquerNotifLue(notifId: String) {
        viewModelScope.launch { notificationService.marquerCommeLue(notifId) }
    }

    fun toutMarquerLue() {
        val uid = currentUserProfile?.id ?: return
        viewModelScope.launch { notificationService.toutMarquerCommeLu(uid) }
    }

    fun toggleFavorite(articleId: String) {
        if (favoriIds.contains(articleId)) favoriIds.remove(articleId)
        else favoriIds.add(articleId)
    }

    fun addArticle(article: Article, context: Context) {
        viewModelScope.launch { firestoreService.addArticle(article, currentUserProfile, context) }
    }

    fun addDon(don: Don, context: Context) {
        viewModelScope.launch { firestoreService.addDon(don, currentUserProfile, context) }
    }

    fun deleteDon(donId: String) {
        viewModelScope.launch { firestoreService.deleteDon(donId) }
    }
    
    fun deleteArticle(articleId: String) {
        viewModelScope.launch { firestoreService.deleteArticle(articleId) }
    }

    fun acheterArticle(
        article: Article,
        provider: String,
        phone: String,
        mode: ModeLivraison,
        adresse: String,
        prixNegocie: Int? = null,
        onResult: (Boolean) -> Unit
    ) {
        val uid = currentUserProfile?.id ?: return
        viewModelScope.launch {
            val success = firestoreService.processPurchase(
                item = article,
                buyerId = uid,
                provider = provider,
                phoneNumber = phone,
                modeLivraison = mode,
                adresseLivraison = adresse,
                prixNegocie = prixNegocie
            )
            onResult(success)
        }
    }

    fun demarrerDiscussion(article: Article, onResult: (String?) -> Unit) {
        val uid = currentUserProfile?.id
        if (uid == null) {
            onResult(null)
            return
        }
        viewModelScope.launch {
            val convId = firestoreService.getOrCreateConversation(
                buyerId = uid,
                sellerId = article.vendeurId,
                itemId = article.firestoreId,
                sellerName = article.vendeur
            )
            if (convId != null) {
                // Optimisation locale pour navigation immédiate
                if (conversations.none { it.id == convId }) {
                    conversations.add(0, ConversationMetadata(
                        id = convId,
                        buyerId = uid,
                        sellerId = article.vendeurId,
                        itemId = article.firestoreId,
                        lastMessage = "Nouvelle conversation",
                        lastMessageTimestamp = com.google.firebase.Timestamp.now(),
                        otherUserName = article.vendeur
                    ))
                }
            }
            onResult(convId)
        }
    }

    fun faireOffre(article: Article, prix: Int, onResult: (String?) -> Unit) {
        val uid = currentUserProfile?.id
        if (uid == null) {
            onResult(null)
            return
        }
        viewModelScope.launch {
            val convId = firestoreService.getOrCreateConversation(
                buyerId = uid,
                sellerId = article.vendeurId,
                itemId = article.firestoreId,
                sellerName = article.vendeur
            )
            if (convId != null) {
                val success = firestoreService.sendOffer(convId, uid, prix)
                if (success) {
                    // Optimisation locale pour navigation immédiate
                    if (conversations.none { it.id == convId }) {
                        conversations.add(0, ConversationMetadata(
                            id = convId,
                            buyerId = uid,
                            sellerId = article.vendeurId,
                            itemId = article.firestoreId,
                            lastMessage = "💰 Offre : $prix F",
                            lastMessageTimestamp = com.google.firebase.Timestamp.now(),
                            otherUserName = article.vendeur
                        ))
                    }
                }
                onResult(if (success) convId else null)
            } else {
                onResult(null)
            }
        }
    }

    fun soumettreCertification(nom: String, cni: String, adresse: String, activite: String, onResult: (Boolean) -> Unit) {
        val uid = currentUserProfile?.id ?: return
        viewModelScope.launch {
            val success = firestoreService.demanderCertification(uid, nom, cni, adresse, activite)
            onResult(success)
        }
    }

    suspend fun changerPhotoProfil(uri: android.net.Uri, context: Context): Boolean {
        val uid = currentUserProfile?.id ?: return false
        val success = firestoreService.updateProfileImage(uid, uri, context)
        if (success) {
            currentUserProfile = firestoreService.getCurrentUserProfile()
        }
        return success
    }

    fun deconnexion() {
        auth.signOut()
        currentUserProfile = null
        articles.clear()
        mesArticles.clear()
        mesDons.clear()
        donsDisponibles.clear()
        notifications.clear()
        conversations.clear()
        nonLuesCount = 0
    }
}
