package com.example.djassaeco// Duplicate file to be removed or ignored.
// The active MainActivity is located in com.djassaeco package.
