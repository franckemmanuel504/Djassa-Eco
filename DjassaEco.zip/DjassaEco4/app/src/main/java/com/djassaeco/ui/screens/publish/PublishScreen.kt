package com.djassaeco.ui.screens.publish

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublishScreen(onBack: () -> Unit, onPublish: (Article) -> Unit) {
    val context = LocalContext.current

    var typeAnnonce by remember { mutableStateOf(TypeAnnonce.VENTE) }
    var titre          by remember { mutableStateOf("") }
    var description    by remember { mutableStateOf("") }
    var selectedImages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var showPhotoOptions by remember { mutableStateOf(false) }
    var tempCameraUri  by remember { mutableStateOf<Uri?>(null) }

    // Champs partagés
    var prix         by remember { mutableStateOf("") }

    // Champs VENTE
    var selectedCat  by remember { mutableStateOf(Categorie.VETEMENTS) }
    var selectedEtat by remember { mutableStateOf(EtatArticle.BON_ETAT) }

    // Champs DECHET_TEXTILE
    var quantiteKg by remember { mutableStateOf("") }
    var typeTissu  by remember { mutableStateOf("") }
    var origine    by remember { mutableStateOf(OrigineDechet.COUTURIER) }

    val isFormValid = titre.isNotBlank() && description.isNotBlank() && 
                     selectedImages.isNotEmpty() && prix.isNotBlank() &&
                     (typeAnnonce != TypeAnnonce.DECHET_TEXTILE || quantiteKg.isNotBlank())

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> uri?.let { selectedImages = selectedImages + it } }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success -> if (success) tempCameraUri?.let { selectedImages = selectedImages + it } }

    fun launchCamera() {
        val dir = File(context.cacheDir, "images").also { it.mkdirs() }
        val file = File(dir, "camera_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(context, "com.djassaeco.fileprovider", file)
        tempCameraUri = uri
        cameraLauncher.launch(uri)
    }

    val sheetState = rememberModalBottomSheetState()

    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight)) {

        Surface(color = Color.White, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Retour") }
                Text("Déposer une annonce", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // ── Type d'annonce ──
            PubCard(title = "Type d'annonce") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(TypeAnnonce.VENTE, TypeAnnonce.DECHET_TEXTILE).forEach { type ->
                        val sel = typeAnnonce == type
                        Surface(
                            onClick = {
                                typeAnnonce = type
                                selectedCat = if (type == TypeAnnonce.DECHET_TEXTILE)
                                    Categorie.DECHETS_TEXTILES else Categorie.VETEMENTS
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = if (sel) EcoGreen else Color.White,
                            border = BorderStroke(1.dp, if (sel) EcoGreen else BorderColor)
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(if (type == TypeAnnonce.VENTE) "🛍️" else "🧵", fontSize = 22.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    type.label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (sel) Color.White else TextTertiary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            // ── Photos ──
            PubCard(title = "Photos (obligatoire)") {
                if (selectedImages.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(2.dp, EcoGreen, RoundedCornerShape(16.dp))
                            .background(Color(0xFFF0FDF8))
                            .clickable { showPhotoOptions = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PhotoCamera, null, tint = EcoGreen, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Ajouter des photos", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = EcoGreen)
                            Text("Galerie ou appareil photo", fontSize = 11.sp, color = TextTertiary)
                        }
                    }
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(selectedImages) { uri ->
                            Box(modifier = Modifier.size(110.dp)) {
                                AsyncImage(
                                    model = uri,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                IconButton(
                                    onClick = { selectedImages = selectedImages.filter { it != uri } },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(24.dp)
                                        .background(Color.Black.copy(0.5f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                        if (selectedImages.size < 5) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .size(110.dp)
                                        .border(1.5.dp, BorderColor, RoundedCornerShape(12.dp))
                                        .background(Color(0xFFFAFAFA), RoundedCornerShape(12.dp))
                                        .clickable { showPhotoOptions = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.Add, null, tint = Color.Gray)
                                        Text("Ajouter", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ── Formulaire Spécifique ──
            if (typeAnnonce == TypeAnnonce.VENTE) {
                PubCard(title = "Informations de vente") {
                    PubField("Titre de l'annonce", titre, { titre = it }, "Ex: Vans authentiques taille 42")
                    Spacer(Modifier.height(14.dp))
                    PubField("Prix (F CFA)", prix, { prix = it }, "Ex: 5000")
                    Spacer(Modifier.height(14.dp))

                    PubLabel("Catégorie")
                    Spacer(Modifier.height(8.dp))
                    val categoriesVente = listOf(
                        Categorie.VETEMENTS, Categorie.CHAUSSURES,
                        Categorie.RECYCLE,
                        Categorie.LIVRES, Categorie.SCOLAIRE,
                        Categorie.MOBILIER, Categorie.JOUETS
                    )
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        categoriesVente.forEach { cat ->
                            val sel = selectedCat == cat
                            FilterChip(
                                selected = sel,
                                onClick = { selectedCat = cat },
                                label = { Text(cat.label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = EcoGreen, selectedLabelColor = Color.White)
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    PubLabel("État de l'article")
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EtatArticle.entries.forEach { etat ->
                            val sel = selectedEtat == etat
                            FilterChip(
                                selected = sel,
                                onClick = { selectedEtat = etat },
                                label = { Text(etat.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = EcoGreen, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }
            } else {
                PubCard(title = "Informations sur les déchets textiles") {
                    Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFFF0EE), modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("🧵", fontSize = 16.sp)
                            Text(
                                "Sera publié automatiquement dans la catégorie Déchets Textiles sur l'accueil.",
                                fontSize = 11.sp, color = Color(0xFFD85A30)
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    PubField("Titre / Description du tissu", titre, { titre = it }, "Ex: Chutes de Bazin bleu")
                    Spacer(Modifier.height(14.dp))
                    PubField("Prix (F CFA)", prix, { prix = it }, "Ex: 2000")
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(modifier = Modifier.weight(1f)) { PubField("Quantité (Kg)", quantiteKg, { quantiteKg = it }, "Ex: 5.0") }
                        Column(modifier = Modifier.weight(1f)) { PubField("Type de tissu", typeTissu, { typeTissu = it }, "Ex: Coton...") }
                    }
                }
            }

            PubCard(title = "Description") {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text("Détails supplémentaires...", color = TextHint, fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth().height(110.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = BorderColor, focusedBorderColor = EcoGreen)
                )
            }
        }

        // ── Bouton Publier ──
        Surface(color = Color.White, shadowElevation = 8.dp) {
            Button(
                onClick = {
                    onPublish(Article(
                        id             = UUID.randomUUID().toString(),
                        firestoreId    = "",
                        titre          = titre,
                        prix           = prix.toIntOrNull() ?: 0,
                        vendeur        = "Moi",
                        initiales      = "ME",
                        couleurVendeur = 0xFF1DB97A,
                        categorie      = if (typeAnnonce == TypeAnnonce.DECHET_TEXTILE) Categorie.DECHETS_TEXTILES else selectedCat,
                        etat           = selectedEtat,
                        description    = description,
                        typeAnnonce    = typeAnnonce,
                        quantiteKg     = quantiteKg.toDoubleOrNull(),
                        typeTissu      = typeTissu.ifBlank { null },
                        origineDechet  = if (typeAnnonce == TypeAnnonce.DECHET_TEXTILE) origine else null,
                        images         = selectedImages
                    ))
                },
                enabled  = isFormValid,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).height(52.dp),
                shape    = RoundedCornerShape(14.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen, disabledContainerColor = Color.LightGray)
            ) {
                Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Publier l'annonce", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }

    if (showPhotoOptions) {
        ModalBottomSheet(onDismissRequest = { showPhotoOptions = false }, sheetState = sheetState, containerColor = Color.White) {
            Column(modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp, start = 16.dp, end = 16.dp, top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Ajouter une photo", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                ListItem(headlineContent = { Text("Prendre une photo") }, leadingContent = { Icon(Icons.Default.PhotoCamera, null, tint = EcoGreen) }, modifier = Modifier.clickable { launchCamera(); showPhotoOptions = false })
                ListItem(headlineContent = { Text("Choisir depuis la galerie") }, leadingContent = { Icon(Icons.Default.Image, null, tint = EcoGreen) }, modifier = Modifier.clickable { photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)); showPhotoOptions = false })
            }
        }
    }
}

@Composable
fun PubCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary, letterSpacing = .5.sp)
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun PubLabel(text: String) {
    Text(text.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary, letterSpacing = .5.sp)
}

@Composable
fun PubField(label: String, value: String, onValueChange: (String) -> Unit, placeholder: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        PubLabel(label)
        OutlinedTextField(
            value = value, onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = TextHint, fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = BorderColor, focusedBorderColor = EcoGreen, unfocusedContainerColor = Color(0xFFFAFAFA)),
            singleLine = true
        )
    }
}
