package com.djassaeco.data.model

import android.net.Uri

fun Review.toAvisUI(): Avis = Avis(
    id           = id,
    auteur       = buyerName,
    initiales    = buyerInitiales,
    couleur      = buyerColor,
    note         = note,
    commentaire  = commentaire,
    dateRelative = "Récent"
)

fun Item.toArticleUI(): Article = Article(
    id             = id,
    firestoreId    = id,
    titre          = title,
    prix           = price,
    vendeur        = if (sellerName.isNotEmpty()) sellerName else "Vendeur",
    vendeurId      = sellerId,
    initiales      = if (sellerInitials.isNotEmpty()) sellerInitials else "V",
    couleurVendeur = sellerColor,
    estVerifie     = sellerIsVerified,
    nombreVentes   = sellerNombreVentes,
    note           = sellerNote,
    categorie      = try { Categorie.valueOf(categorie) } catch(e: Exception) { Categorie.TOUT },
    etat           = try { EtatArticle.valueOf(etat) } catch(e: Exception) { EtatArticle.BON_ETAT },
    description    = description,
    localisation   = location,
    typeAnnonce    = try { TypeAnnonce.valueOf(typeAnnonce) } catch(e: Exception) { TypeAnnonce.VENTE },
    quantiteKg     = quantiteKg,
    typeTissu      = typeTissu,
    origineDechet  = origineDechet?.let { try { OrigineDechet.valueOf(it) } catch(e: Exception) { null } },
    images         = images.map { Uri.parse(it) }
)

fun DonFirestore.toDonUI(): Don = Don(
    id            = id,
    donateur      = donateur,
    donateurId    = donateurId,
    telephone     = telephone,
    localisation  = localisation,
    typeDon       = typeDon,
    etat          = try { EtatArticle.valueOf(etat) } catch(e: Exception) { EtatArticle.BON_ETAT },
    disponibilite = Disponibilite.fromFirestore(disponibiliteType, disponibiliteDetail),
    images        = images.map { Uri.parse(it) },
    typeDestinataire = typeDestinataire
)
