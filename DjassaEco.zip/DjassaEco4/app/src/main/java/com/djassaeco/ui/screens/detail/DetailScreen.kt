package com.djassaeco.ui.screens.detail

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.djassaeco.R
import com.djassaeco.data.model.*
import com.djassaeco.ui.theme.*
import java.util.Locale

@Composable
fun DetailScreen(
    article: Article,
    avis: List<Avis>,
    onBack: () -> Unit,
    onMessage: () -> Unit,
    onNego: () -> Unit,
    onBuy: () -> Unit,
    onSellerClick: (String) -> Unit
) {
    // Recommendation 1: Centralisation de l'image
    val hasImages = article.images.isNotEmpty()

    Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 100.dp)
        ) {
            // --- SECTION IMAGE ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(Color(0xFFF5F5F5)),
                contentAlignment = Alignment.Center
            ) {
                if (hasImages) {
                    AsyncImage(
                        model = article.images.first(),
                        contentDescription = article.titre,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Image(
                        painter = painterResource(id = article.coverImageRes ?: R.drawable.pull_cardina),
                        contentDescription = article.titre,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                
                Row(modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(3) { i -> 
                        Box(modifier = Modifier
                            .size(if (i == 0) 18.dp else 6.dp, 6.dp)
                            .clip(CircleShape)
                            .background(if (i == 0) Color.White else Color.White.copy(.5f))) 
                    }
                }
                
                Row(modifier = Modifier.align(Alignment.TopStart).fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = onBack, modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(.9f))) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour", modifier = Modifier.size(20.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        IconButton(onClick = {}, modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(.9f))) {
                            Icon(Icons.Default.Share, contentDescription = "Partager", modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = {}, modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(.9f))) {
                            Icon(Icons.Default.FavoriteBorder, contentDescription = "Favori", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 20.dp)) {
                Text("${article.prix.toPriceFormat()} F CFA", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Text(article.titre, style = MaterialTheme.typography.titleMedium, color = TextSecondary)
                
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = RoundedCornerShape(8.dp), color = if (article.etat == EtatArticle.NEUF) ConditionNewBg else ConditionGoodBg) {
                        Text(article.etat.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (article.etat == EtatArticle.NEUF) ConditionNewText else ConditionGoodText, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                    Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFF0EEFF)) {
                        Text(article.categorie.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5340B7), modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                }

                Spacer(Modifier.height(24.dp))

                Surface(
                    onClick = { onSellerClick(article.vendeurId) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFF7F7F7)
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(article.couleurVendeur)), contentAlignment = Alignment.Center) {
                            Text(article.initiales, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(article.vendeur, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                                if (article.estVerifie) Icon(Icons.Default.Verified, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(16.dp))
                            }
                            Text("Vendeur vérifié · ${article.nombreVentes} ventes", fontSize = 11.sp, color = EcoGreen, fontWeight = FontWeight.SemiBold)
                            Text("⭐ ${article.note} · ${article.localisation}", fontSize = 11.sp, color = TextTertiary, modifier = Modifier.padding(top = 2.dp))
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFFCCCCCC))
                    }
                }

                Spacer(Modifier.height(24.dp))

                Text("Description", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text(article.description.ifBlank { "Article en très bon état." }, fontSize = 14.sp, color = TextSecondary, lineHeight = 22.sp)
            }
        }

        // --- BARRE DE BOUTONS ---
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding(),
            color = Color.White,
            shadowElevation = 15.dp,
            border = BorderStroke(1.dp, Color(0xFFF0F0F0))
        ) {
            Row(modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = onMessage, modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.5.dp, EcoGreen)) {
                    Text("Message", color = EcoGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                OutlinedButton(onClick = onNego, modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.5.dp, Color(0xFFFFB300))) {
                    Text("Négocier", color = Color(0xFFE67E00), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Button(onClick = onBuy, modifier = Modifier.weight(1.3f).height(50.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)) {
                    Text("Acheter", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun AvisCard(avis: Avis) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFF9F9F7), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(avis.couleur)), contentAlignment = Alignment.Center) {
                    Text(avis.initiales, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(avis.auteur, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                    Row { repeat(5) { i -> Text(if (i < avis.note) "⭐" else "☆", fontSize = 12.sp) } }
                }
                Text(avis.dateRelative, fontSize = 11.sp, color = TextTertiary)
            }
            Spacer(Modifier.height(8.dp))
            Text("\"${avis.commentaire}\"", fontSize = 12.sp, color = TextSecondary, lineHeight = 18.sp)
        }
    }
}

fun Int.toPriceFormat(): String {
    return if (this >= 1000) {
        val thousands = this / 1000
        val remainder = this % 1000
        String.format(Locale.FRENCH, "%d %03d", thousands, remainder)
    } else this.toString()
}
