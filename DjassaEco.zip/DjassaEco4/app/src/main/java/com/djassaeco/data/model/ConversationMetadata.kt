package com.djassaeco.data.model

import com.google.firebase.Timestamp

data class ConversationMetadata(
    val id: String = "",
    val buyerId: String = "",
    val sellerId: String = "",
    val itemId: String = "",
    var lastMessage: String = "",
    var lastMessageTimestamp: Timestamp = Timestamp.now(),
    var otherUserName: String = "",
    var lastOfferStatus: String? = null,
    var lastPriceProposed: Int? = null
)
