package com.djassaeco

import android.app.Application
import org.osmdroid.config.Configuration

class DjassaEcoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Obligatoire : identifier ton app auprès d'OSM
        Configuration.getInstance().userAgentValue = "DjassaEco/1.0"
        Configuration.getInstance().load(
            this,
            getSharedPreferences("osmdroid", MODE_PRIVATE)
        )
    }
}
