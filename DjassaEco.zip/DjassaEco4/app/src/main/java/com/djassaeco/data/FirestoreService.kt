package com.djassaeco.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.cloudinary.android.MediaManager
import com.cloudinary.android.callback.ErrorInfo
import com.cloudinary.android.callback.UploadCallback
import com.djassaeco.data.model.*
import com.djassaeco.data.model.Transaction as ModelTransaction
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Transaction as FirestoreTransaction
import kotlin.coroutines.resume
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirestoreService {

    private val db   = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    // Références des collections
    private val usersCollection         = db.collection("users")
    private val itemsCollection         = db.collection("items")
    private val transactionsCollection  = db.collection("transactions")
    private val donsCollection          = db.collection("dons")
    private val conversationsCollection = db.collection("conversations")
    private val reviewsCollection       = db.collection("reviews")
    private val certificationsCollection = db.collection("certifications")

    // ─── CLOUDINARY UPLOAD ──────────────────────────────────────────

    suspend fun uploadImage(uri: Uri, context: Context, dossier: String = "items"): String? {
        return try {
            suspendCancellableCoroutine { cont ->
                MediaManager.get().upload(uri)
                    .option("upload_preset", "djassa_preset")
                    .option("folder", "djassaeco/$dossier")
                    .option("resource_type", "image")
                    .option("transformation", "c_limit,w_1000,h_1000,q_auto:eco,f_auto")
                    .callback(object : UploadCallback {
                        override fun onSuccess(requestId: String, resultData: Map<*, *>) {
                            val url = resultData["secure_url"] as? String
                            cont.resume(url)
                        }
                        override fun onError(requestId: String?, error: ErrorInfo?) {
                            Log.e("Cloudinary", "Upload error: ${error?.description}")
                            cont.resume(null)
                        }
                        override fun onStart(requestId: String?) {}
                        override fun onProgress(requestId: String?, bytes: Long, totalBytes: Long) {}
                        override fun onReschedule(requestId: String?, error: ErrorInfo?) {}
                    })
                    .dispatch()
            }
        } catch (e: Exception) {
            Log.e("Cloudinary", "Exception during upload", e)
            null
        }
    }

    // ─── USERS ────────────────────────────────────────────────────────

    suspend fun saveUserProfile(profile: UserProfile): Boolean {
        return try {
            usersCollection.document(profile.id).set(profile).await()
            true
        } catch (e: Exception) {
            Log.e("FirestoreService", "Error saving profile", e)
            false
        }
    }

    /** Appelé à l'inscription — crée le document users/{uid} */
    suspend fun saveUserProfile(uid: String, nom: String, email: String, telephone: String): Boolean {
        val names = nom.trim().split(" ")
        val profile = UserProfile(
            id        = uid,
            firstName = names.getOrNull(0) ?: "",
            lastName  = if (names.size > 1) names.subList(1, names.size).joinToString(" ") else "",
            location  = "Abidjan",
            telephone = telephone
        )
        return saveUserProfile(profile)
    }

    suspend fun getCurrentUserProfile(): UserProfile? {
        val uid = auth.currentUser?.uid ?: return null
        return try {
            usersCollection.document(uid).get().await().toObject(UserProfile::class.java)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getUserProfile(uid: String): UserProfile? {
        return try {
            usersCollection.document(uid).get().await().toObject(UserProfile::class.java)
        } catch (e: Exception) { null }
    }

    /** Met à jour uniquement les champs modifiables du profil */
    suspend fun updateUserProfile(uid: String, fields: Map<String, Any>): Boolean {
        return try {
            usersCollection.document(uid).update(fields).await()
            true
        } catch (e: Exception) { false }
    }

    suspend fun updateProfileImage(uid: String, uri: Uri, context: Context): Boolean {
        val url = uploadImage(uri, context, dossier = "profiles/$uid") ?: return false
        return updateUserProfile(uid, mapOf("profileImageUrl" to url))
    }

    // ═══════════════════════════════════════════════════════════════
    //  CERTIFICATION
    // ═══════════════════════════════════════════════════════════════

    suspend fun demanderCertification(
        userId: String,
        nom: String,
        cni: String,
        adresse: String,
        activite: String
    ): Boolean {
        return try {
            val certifData = mapOf(
                "userId" to userId,
                "nomComplet" to nom,
                "numeroCni" to cni,
                "adresse" to adresse,
                "activite" to activite,
                "status" to "PENDING",
                "createdAt" to Timestamp.now()
            )
            certificationsCollection.document(userId).set(certifData).await()
            true
        } catch (e: Exception) {
            Log.e("FirestoreService", "Error submitting certification", e)
            false
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  ITEMS (Articles)
    // ═══════════════════════════════════════════════════════════════

    suspend fun addArticle(article: Article, userProfile: UserProfile?, context: Context): Boolean {
        return try {
            val docRef = itemsCollection.document()
            val imageUrls = article.images.mapNotNull { uri ->
                uploadImage(uri, context, dossier = "items/${docRef.id}")
            }

            val item = Item(
                id            = docRef.id,
                sellerId      = userProfile?.id ?: "unknown",
                sellerName    = userProfile?.fullName ?: "Vendeur",
                sellerInitials = userProfile?.initiales ?: "V",
                sellerColor   = 0xFF1DB97A,
                sellerIsVerified = true,
                sellerNombreVentes = userProfile?.nombreVentes ?: (10..50).random(),
                sellerNote    = userProfile?.note ?: 4.5f,
                title         = article.titre,
                description   = article.description,
                price         = article.prix,
                images        = imageUrls,
                status        = "available",
                createdAt     = Timestamp.now(),
                categorie     = article.categorie.name,
                typeAnnonce   = article.typeAnnonce.name,
                etat          = article.etat.name,
                location      = userProfile?.location ?: "Abidjan",
                quantiteKg    = article.quantiteKg,
                typeTissu     = article.typeTissu,
                origineDechet = article.origineDechet?.name
            )
            docRef.set(item).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Retourne tous les articles (Vente et Déchet Textile) pour qu'ils apparaissent dans la catégorie "Tout" */
    fun getArticlesFlow(): Flow<List<Article>> = callbackFlow {
        val sub = itemsCollection
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("Firestore", "Articles listen error", error)
                    return@addSnapshotListener
                }
                val items = snapshot?.toObjects(Item::class.java) ?: emptyList()
                val articles = items.map { it.toArticleUI() }
                trySend(articles)
            }
        awaitClose { sub.remove() }
    }

    fun getDechetsTextileFlow(): Flow<List<Article>> = callbackFlow {
        val sub = itemsCollection
            .whereEqualTo("typeAnnonce", "DECHET_TEXTILE")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(20)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    return@addSnapshotListener
                }
                val items = snapshot?.toObjects(Item::class.java) ?: emptyList()
                val articles = items.map { it.toArticleUI() }
                trySend(articles)
            }
        awaitClose { sub.remove() }
    }

    fun getArticlesBySellerFlow(sellerId: String): Flow<List<Article>> = callbackFlow {
        // Attention : nécessite l'index (sellerId, status, createdAt DESC)
        val sub = itemsCollection
            .whereEqualTo("sellerId", sellerId)
            .whereEqualTo("status", "available")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    return@addSnapshotListener
                }
                val items = snapshot?.toObjects(Item::class.java) ?: emptyList()
                val articles = items.map { it.toArticleUI() }
                trySend(articles)
            }
        awaitClose { sub.remove() }
    }

    suspend fun deleteArticle(itemId: String): Boolean {
        return try {
            itemsCollection.document(itemId).delete().await()
            true
        } catch (e: Exception) {
            false
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  DONS
    // ═══════════════════════════════════════════════════════════════

    suspend fun addDon(don: Don, userProfile: UserProfile?, context: Context): Boolean {
        return try {
            val imageUrls = don.images.mapNotNull { uri ->
                uploadImage(uri, context, dossier = "dons/${don.id}")
            }

            val donFirestore = DonFirestore(
                id                  = don.id,
                donateurId          = userProfile?.id ?: "",
                donateur            = userProfile?.fullName ?: don.donateur ?: "",
                telephone           = don.telephone,
                localisation        = don.localisation,
                typeDon             = don.typeDon,
                etat                = don.etat.name,
                disponibiliteType   = don.disponibilite.toFirestoreType(),
                disponibiliteDetail = don.disponibilite.toFirestoreDetail(),
                images              = imageUrls,
                status              = "disponible",
                createdAt           = Timestamp.now(),
                typeDestinataire    = don.typeDestinataire
            )
            donsCollection.document(don.id).set(donFirestore).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getDonsFlow(): Flow<List<Don>> = callbackFlow {
        val sub = donsCollection
            .whereEqualTo("status", "disponible")
            .whereEqualTo("typeDestinataire", "PARTICULIER")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(20)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("Firestore", "Dons listen error", error)
                    return@addSnapshotListener
                }
                val donsFirestore = snapshot?.toObjects(DonFirestore::class.java) ?: emptyList()
                val dons = donsFirestore.map { it.toDonUI() }
                trySend(dons)
            }
        awaitClose { sub.remove() }
    }

    fun getMesDonsFlow(uid: String): Flow<List<Don>> = callbackFlow {
        // Nécessite l'index (donateurId, createdAt DESC)
        val sub = donsCollection
            .whereEqualTo("donateurId", uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    return@addSnapshotListener
                }
                val donsFirestore = snapshot?.toObjects(DonFirestore::class.java) ?: emptyList()
                val dons = donsFirestore.map { it.toDonUI() }
                trySend(dons)
            }
        awaitClose { sub.remove() }
    }

    suspend fun deleteDon(donId: String): Boolean {
        return try {
            donsCollection.document(donId).delete().await()
            true
        } catch (e: Exception) {
            false
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  CONVERSATIONS
    // ═══════════════════════════════════════════════════════════════

    suspend fun getOrCreateConversation(
        buyerId: String,
        sellerId: String,
        itemId: String,
        sellerName: String
    ): String? {
        return try {
            val existing = conversationsCollection
                .whereEqualTo("buyerId", buyerId)
                .whereEqualTo("sellerId", sellerId)
                .whereEqualTo("itemId", itemId)
                .limit(1)
                .get().await()

            if (!existing.isEmpty) {
                existing.documents.first().id
            } else {
                val docRef = conversationsCollection.document()
                val conv = ConversationMetadata(
                    id                    = docRef.id,
                    buyerId               = buyerId,
                    sellerId              = sellerId,
                    itemId                = itemId,
                    lastMessage           = "Nouvelle conversation",
                    lastMessageTimestamp  = Timestamp.now(),
                    otherUserName         = sellerName
                )
                docRef.set(conv).await()
                docRef.id
            }
        } catch (e: Exception) {
            null
        }
    }

    fun getConversationsFlow(uid: String): Flow<List<ConversationMetadata>> {
        val buyerFlow = callbackFlow {
            val sub = conversationsCollection
                .whereEqualTo("buyerId", uid)
                .orderBy("lastMessageTimestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, _ ->
                    trySend(snapshot?.toObjects(ConversationMetadata::class.java) ?: emptyList())
                }
            awaitClose { sub.remove() }
        }

        val sellerFlow = callbackFlow {
            val sub = conversationsCollection
                .whereEqualTo("sellerId", uid)
                .orderBy("lastMessageTimestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, _ ->
                    trySend(snapshot?.toObjects(ConversationMetadata::class.java) ?: emptyList())
                }
            awaitClose { sub.remove() }
        }

        return combine(buyerFlow, sellerFlow) { b, s -> (b + s).sortedByDescending { it.lastMessageTimestamp } }
    }

    suspend fun sendMessage(conversationId: String, message: ChatMessage): Boolean {
        return try {
            val docRef = conversationsCollection.document(conversationId).collection("messages").document()
            message.id = docRef.id
            docRef.set(message).await()
            
            val updateData = mutableMapOf<String, Any>(
                "lastMessage" to if (message.isOffre) "💰 Offre : ${message.prixPropose} FCFA" else message.text,
                "lastMessageTimestamp" to message.timestamp
            )
            
            if (message.isOffre) {
                updateData["lastOfferStatus"] = "PENDING"
                updateData["lastPriceProposed"] = message.prixPropose ?: 0
            }

            conversationsCollection.document(conversationId).update(updateData).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getMessagesFlow(conversationId: String): Flow<List<ChatMessage>> = callbackFlow {
        val sub = conversationsCollection
            .document(conversationId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    return@addSnapshotListener
                }
                trySend(snapshot?.toObjects(ChatMessage::class.java) ?: emptyList())
            }
        awaitClose { sub.remove() }
    }

    // ═══════════════════════════════════════════════════════════════
    //  REVIEWS & PAIEMENT
    // ═══════════════════════════════════════════════════════════════

    suspend fun processPurchase(
        item: Article,
        buyerId: String,
        provider: String,
        phoneNumber: String,
        modeLivraison: ModeLivraison = ModeLivraison.Retrait,
        adresseLivraison: String = "",
        prixNegocie: Int? = null
    ): Boolean {
        return try {
            val transactionId = UUID.randomUUID().toString()
            val montantArticle = prixNegocie ?: item.prix
            val fraisLivraison = modeLivraison.frais

            // ✅ CALCUL COMMISSION 5%
            val commission     = (montantArticle * 0.05).toInt()
            val montantVendeur = montantArticle - commission
            val montantTotal   = montantArticle + fraisLivraison

            db.runTransaction { ref ->
                val sellerDoc   = usersCollection.document(item.vendeurId)
                val platformDoc = usersCollection.document("DJASSAECO_PLATFORM")
                val itemDoc     = itemsCollection.document(item.firestoreId)
                val transDoc    = transactionsCollection.document(transactionId)

                val transactionData = ModelTransaction(
                    id               = transactionId,
                    itemId           = item.firestoreId,
                    buyerId          = buyerId,
                    sellerId         = item.vendeurId,
                    amount           = montantTotal,
                    prixOriginal     = item.prix,
                    prixNegocie      = prixNegocie,
                    status           = TransactionStatus.PAID.name,
                    modeLivraison    = modeLivraison.toFirestoreString(),
                    fraisLivraison   = fraisLivraison,
                    adresseLivraison = adresseLivraison,
                    paymentProvider  = provider,
                    payerPhone       = phoneNumber,
                    commission       = commission,
                    montantVendeur   = montantVendeur,
                    createdAt        = Timestamp.now()
                )

                ref.update(sellerDoc, "escrowBalance", FieldValue.increment(montantVendeur.toLong()))
                ref.update(platformDoc, "walletBalance", FieldValue.increment(commission.toLong()))
                ref.update(itemDoc, "status", "pending_delivery")
                ref.set(transDoc, transactionData)
                null
            }.await()
            true
        } catch (e: Exception) {
            Log.e("FirestoreService", "Erreur lors de l'achat", e)
            false
        }
    }

    suspend fun confirmerReception(transactionId: String): Boolean {
        return try {
            val trans = transactionsCollection.document(transactionId)
                .get().await().toObject(ModelTransaction::class.java) ?: return false

            if (trans.status == TransactionStatus.COMPLETED.name) return true

            db.runTransaction { ref ->
                val sellerDoc = usersCollection.document(trans.sellerId)
                val itemDoc   = itemsCollection.document(trans.itemId)
                val transDoc  = transactionsCollection.document(transactionId)

                ref.update(sellerDoc, "escrowBalance", FieldValue.increment(-trans.montantVendeur.toLong()))
                ref.update(sellerDoc, "walletBalance",  FieldValue.increment(trans.montantVendeur.toLong()))
                ref.update(sellerDoc, "nombreVentes",   FieldValue.increment(1))
                ref.update(itemDoc,   "status", "sold")
                ref.update(transDoc,  "status", TransactionStatus.COMPLETED.name)
                null
            }.await()
            true
        } catch (e: Exception) {
            Log.e("FirestoreService", "Error confirming reception", e)
            false
        }
    }

    suspend fun sendOffer(conversationId: String, senderId: String, price: Int): Boolean {
        val message = ChatMessage(
            senderId = senderId,
            text = "💰 Offre de prix : $price F CFA",
            isOffre = true,
            prixPropose = price,
            offreStatut = "PENDING"
        )
        return sendMessage(conversationId, message)
    }

    fun getReviewsForSellerFlow(sellerId: String): Flow<List<Avis>> = callbackFlow {
        val sub = reviewsCollection
            .whereEqualTo("sellerId", sellerId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    return@addSnapshotListener
                }
                val avisFirestore = snapshot?.toObjects(Review::class.java) ?: emptyList()
                val avis = avisFirestore.map { it.toAvisUI() }
                trySend(avis)
            }
        awaitClose { sub.remove() }
    }
}
