package com.djassaeco.data.model

import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.firestore.Exclude
import java.util.UUID

// ═══════════════════════════════════════════════════════════════════
//  MODÈLES FIRESTORE
// ═══════════════════════════════════════════════════════════════════

data class UserProfile(
    var id: String = "",
    var firstName: String = "",
    var lastName: String = "",
    var location: String = "Abidjan",
    var profileImageUrl: String? = null,
    var createdAt: Timestamp = Timestamp.now(),
    var telephone: String = "",
    var bio: String = "",
    var lienInstagram: String = "",
    var lienFacebook: String = "",
    var walletBalance: Int = 0,
    var escrowBalance: Int = 0,
    var nombreVentes: Int = 0,
    var note: Float = 0f
) {
    @get:Exclude
    val fullName: String get() = "$firstName $lastName".trim().ifEmpty { "Utilisateur" }
    
    @get:Exclude
    val initiales: String get() = if (firstName.isNotEmpty() && lastName.isNotEmpty()) "${firstName.take(1)}${lastName.take(1)}".uppercase() else if (firstName.isNotEmpty()) firstName.take(1).uppercase() else "U"
}

data class Item(
    var id: String = "",
    var sellerId: String = "",
    var sellerName: String = "",
    var sellerInitials: String = "",
    var sellerColor: Long = 0xFF1DB97A,
    var sellerIsVerified: Boolean = false,
    var sellerNombreVentes: Int = 0,
    var sellerNote: Float = 0f,
    var title: String = "",
    var description: String = "",
    var price: Int = 0,
    var imageUrl: String? = null,
    var images: List<String> = emptyList(),
    var status: String = "available",
    var createdAt: Timestamp = Timestamp.now(),
    var categorie: String = "TOUT",
    var typeAnnonce: String = "VENTE",
    var etat: String = "BON_ETAT",
    var location: String = "Abidjan",
    var quantiteKg: Double? = null,
    var typeTissu: String? = null,
    var origineDechet: String? = null
)

enum class TransactionStatus { PENDING, PAID, COMPLETED, CANCELLED }

data class Transaction(
    var id: String = "",
    var itemId: String = "",
    var buyerId: String = "",
    var sellerId: String = "",
    var amount: Int = 0,
    var prixOriginal: Int = 0,
    var prixNegocie: Int? = null,
    var status: String = "PENDING",
    var modeLivraison: String = "Retrait",
    var fraisLivraison: Int = 0,
    var adresseLivraison: String = "",
    var paymentProvider: String = "",
    var payerPhone: String = "",
    var commission: Int = 0,
    var montantVendeur: Int = 0,
    var createdAt: Timestamp = Timestamp.now()
)

data class DonFirestore(
    var id: String = "",
    var donateurId: String = "",
    var donateur: String = "",
    var telephone: String = "",
    var localisation: String = "",
    var typeDon: String = "",
    var etat: String = "BON_ETAT",
    var disponibiliteType: String = "JOUR",
    var disponibiliteDetail: String = "",
    var images: List<String> = emptyList(),
    var status: String = "disponible",
    var createdAt: Timestamp = Timestamp.now(),
    var typeDestinataire: String = "PARTICULIER"
)

data class ChatMessage(
    var id: String = "",
    var senderId: String = "",
    var text: String = "",
    var imageUrl: String? = null,
    var timestamp: Timestamp = Timestamp.now(),
    var status: String = "ENVOYE",
    var isOffre: Boolean = false,
    var prixPropose: Int? = null,
    var offreStatut: String? = null,
    var contreOffre: Int? = null
)

data class Review(
    var id: String = "",
    var sellerId: String = "",
    var buyerId: String = "",
    var buyerName: String = "",
    var buyerInitiales: String = "",
    var buyerColor: Long = 0xFF1DB97A,
    var transactionId: String = "",
    var note: Int = 5,
    var commentaire: String = "",
    var createdAt: Timestamp = Timestamp.now()
)

// ═══════════════════════════════════════════════════════════════════
//  MODÈLES UI
// ═══════════════════════════════════════════════════════════════════

data class Article(
    var id: String,
    var firestoreId: String = "",
    var titre: String,
    var prix: Int,
    var vendeur: String,
    var vendeurId: String = "",
    var initiales: String,
    var couleurVendeur: Long,
    var estVerifie: Boolean = false,
    var nombreVentes: Int = 0,
    var note: Float = 0f,
    var estFavori: Boolean = false,
    var description: String = "",
    var localisation: String = "Abidjan",
    var typeAnnonce: TypeAnnonce = TypeAnnonce.VENTE,
    var quantiteKg: Double? = null,
    var typeTissu: String? = null,
    var origineDechet: OrigineDechet? = null,
    var images: List<Uri> = emptyList(),
    var coverImageRes: Int? = null,
    var categorie: Categorie,
    var etat: EtatArticle
)

data class Don(
    var id: String = UUID.randomUUID().toString(),
    var donateur: String? = null,
    var donateurId: String = "",
    var telephone: String = "",
    var localisation: String = "",
    var typeDon: String = "",
    var disponibilite: Disponibilite = Disponibilite.ParJour("", "", ""),
    var etat: EtatArticle = EtatArticle.BON_ETAT,
    var images: List<Uri> = emptyList(),
    var typeDestinataire: String = "PARTICULIER"
)

data class Avis(
    var id: String,
    var auteur: String,
    var initiales: String,
    var couleur: Long,
    var note: Int,
    var commentaire: String,
    var dateRelative: String
)

data class Utilisateur(
    var id: String,
    var nom: String,
    var telephone: String,
    var email: String = "",
    var localisation: String = "Abidjan",
    var profileImageUrl: String? = null,
    var estVerifie: Boolean = false,
    var nombreVentes: Int = 0,
    var note: Float = 0f,
    var nombreDons: Int = 0
)

data class Conversation(
    val id: String,
    val interlocuteur: Utilisateur,
    val article: Article,
    val dernierMessage: String,
    val heure: String,
    var nonLus: Int = 0,
    var enLigne: Boolean = false
)

enum class StatutOffre { EN_ATTENTE, CONTRE_OFFRE, ACCEPTEE, REFUSEE }

enum class TypeAnnonce(val label: String) { VENTE("Vente"), DON("Don"), DECHET_TEXTILE("Déchet Textile") }
enum class OrigineDechet(val label: String) { COUTURIER("Couturier"), USINE("Usine"), ATELIER("Atelier"), AUTRE("Autre") }
enum class EtatArticle(val label: String) { NEUF("Neuf"), COMME_NEUF("Comme neuf"), BON_ETAT("Bon état"), TRES_BON_ETAT("Très bon état"), USE("Usé") }

enum class Categorie(val label: String) {
    TOUT("Tout"),
    DECHETS_TEXTILES("Déchets textiles"),
    RECYCLE("Article recyclé"),
    VETEMENTS("Vêtements"),
    CHAUSSURES("Shoes"),
    LIVRES("Livres"),
    SCOLAIRE("Scolaire"),
    MOBILIER("Mobilier"),
    JOUETS("Jouets")
}

sealed class ModeLivraison(var label: String, var frais: Int, var delai: String) {
    object Retrait     : ModeLivraison("Retrait chez le vendeur", 0,    "Sur rendez-vous")
    object Djassa      : ModeLivraison("Djassa Livraison",        1000, "24–48h")
    object ExpressMoto : ModeLivraison("Express moto",            1500, "Dans 2h")

    fun toFirestoreString(): String = when(this) {
        is Retrait     -> "Retrait"
        is Djassa      -> "Djassa"
        is ExpressMoto -> "ExpressMoto"
    }

    companion object {
        fun fromFirestoreString(s: String): ModeLivraison = when(s) {
            "Djassa"      -> Djassa
            "ExpressMoto" -> ExpressMoto
            else          -> Retrait
        }
    }
}

sealed class Disponibilite {
    data class ParJour(var jour: String, var date: String, var mois: String) : Disponibilite() {
        override fun toString() = "$jour $date $mois"
    }
    data class ParHeure(var heureDebut: String, var heureFin: String, var periode: Periode) : Disponibilite() {
        override fun toString() = "$heureDebut – $heureFin · ${periode.label}"
    }

    fun toFirestoreType(): String   = if (this is ParJour) "JOUR" else "HEURE"
    fun toFirestoreDetail(): String = toString()

    companion object {
        fun fromFirestore(type: String, detail: String): Disponibilite {
            return if (type == "JOUR") {
                val parts = detail.split(" ")
                ParJour(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" }, parts.getOrElse(2) { "" })
            } else {
                try {
                    // detail format: "10:00 – 14:00 · Midi"
                    val parts = detail.split(" · ")
                    val times = parts[0].split(" – ")
                    val label = parts.getOrNull(1) ?: "Matin"
                    val periode = Periode.values().find { it.label == label } ?: Periode.MATIN
                    ParHeure(times[0], times[1], periode)
                } catch (e: Exception) {
                    ParHeure("08:00", "12:00", Periode.MATIN)
                }
            }
        }
    }
}

enum class Periode(val label: String) { MATIN("Matin"), MIDI("Midi"), SOIR("Soir"), NUIT("Nuit") }

// ═══════════════════════════════════════════════════════════════════
//  SAMPLE DATA
// ═══════════════════════════════════════════════════════════════════

object SampleData {
    var articles = emptyList<Article>()
    var avisVendeur = emptyList<Avis>()
    var conversations = emptyList<Conversation>()
    var utilisateurActuel = Utilisateur(id = "", nom = "", telephone = "", email = "", localisation = "Abidjan", estVerifie = false, nombreVentes = 0, note = 0f, nombreDons = 0)
}
