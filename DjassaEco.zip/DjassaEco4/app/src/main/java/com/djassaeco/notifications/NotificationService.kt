package com.djassaeco.notifications

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

// ─────────────────────────────────────────────────────────────────
//  MODÈLE
// ─────────────────────────────────────────────────────────────────

data class DjassaNotification(
    val id: String = "",
    val userId: String = "",
    val type: String = "MESSAGE",
    val titre: String = "",
    val corps: String = "",
    val deepLink: String = "",
    var lue: Boolean = false,
    val createdAt: com.google.firebase.Timestamp = com.google.firebase.Timestamp.now()
)

// ─────────────────────────────────────────────────────────────────
//  SERVICE — Lecture + Envoi de notifications
// ─────────────────────────────────────────────────────────────────

class NotificationService {

    private val db        = FirebaseFirestore.getInstance()
    private val auth      = FirebaseAuth.getInstance()
    private val functions = FirebaseFunctions.getInstance()

    // ═══════════════════════════════════════════════════════════════
    //  LECTURE — Historique des notifications
    // ═══════════════════════════════════════════════════════════════

    fun getNotificationsFlow(uid: String): Flow<List<DjassaNotification>> = callbackFlow {
        val sub = db.collection("notifications")
            .whereEqualTo("userId", uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null) { close(error); return@addSnapshotListener }
                val notifs = snapshot?.documents?.map { doc ->
                    DjassaNotification(
                        id       = doc.id,
                        userId   = doc.getString("userId") ?: "",
                        type     = doc.getString("type") ?: "MESSAGE",
                        titre    = doc.getString("titre") ?: "",
                        corps    = doc.getString("corps") ?: "",
                        deepLink = doc.getString("deepLink") ?: "",
                        lue      = doc.getBoolean("lue") ?: false,
                        createdAt = doc.getTimestamp("createdAt") ?: com.google.firebase.Timestamp.now()
                    )
                } ?: emptyList()
                trySend(notifs)
            }
        awaitClose { sub.remove() }
    }

    /** Nombre de notifications non lues (pour le badge) */
    fun getNonLuesFlow(uid: String): Flow<Int> = callbackFlow {
        val sub = db.collection("notifications")
            .whereEqualTo("userId", uid)
            .whereEqualTo("lue", false)
            .addSnapshotListener { snapshot, _ ->
                trySend(snapshot?.size() ?: 0)
            }
        awaitClose { sub.remove() }
    }

    suspend fun marquerCommeLue(notifId: String) {
        db.collection("notifications").document(notifId).update("lue", true).await()
    }

    suspend fun toutMarquerCommeLu(uid: String) {
        val nonLues = db.collection("notifications")
            .whereEqualTo("userId", uid)
            .whereEqualTo("lue", false)
            .get().await()
        val batch = db.batch()
        nonLues.documents.forEach { doc ->
            batch.update(doc.reference, "lue", true)
        }
        batch.commit().await()
    }

    // ═══════════════════════════════════════════════════════════════
    //  ENVOI — via Firebase Function (côté serveur)
    //  Ces méthodes sont appelées depuis l'app quand un événement
    //  se produit (nouveau message, offre, paiement…)
    // ═══════════════════════════════════════════════════════════════

    /** Notifier le vendeur qu'il a reçu un message */
    suspend fun notifierNouveauMessage(
        destinataireId: String,
        expediteurNom: String,
        messagePreview: String,
        conversationId: String
    ) = envoyerNotification(
        destinataireId = destinataireId,
        type           = "MESSAGE",
        titre          = "💬 Message de $expediteurNom",
        corps          = messagePreview,
        deepLink       = "djassa://chat/$conversationId"
    )

    /** Notifier le vendeur qu'il a reçu une offre */
    suspend fun notifierOffre(
        vendeurId: String,
        acheteurNom: String,
        prixPropose: Int,
        articleTitre: String,
        conversationId: String
    ) = envoyerNotification(
        destinataireId = vendeurId,
        type           = "OFFRE",
        titre          = "💰 Offre reçue sur \"$articleTitre\"",
        corps          = "$acheteurNom propose $prixPropose F CFA",
        deepLink       = "djassa://chat/$conversationId"
    )

    /** Notifier l'acheteur que son offre a été acceptée */
    suspend fun notifierOffreAcceptee(
        acheteurId: String,
        prixAccepte: Int,
        articleTitre: String,
        conversationId: String
    ) = envoyerNotification(
        destinataireId = acheteurId,
        type           = "OFFRE_ACCEPTEE",
        titre          = "✅ Offre acceptée !",
        corps          = "Votre offre de $prixAccepte F sur \"$articleTitre\" a été acceptée. Finalisez l'achat !",
        deepLink       = "djassa://chat/$conversationId"
    )

    /** Notifier le vendeur qu'un paiement est en cours (séquestre) */
    suspend fun notifierPaiementRecu(
        vendeurId: String,
        acheteurNom: String,
        montant: Int,
        articleTitre: String,
        transactionId: String
    ) = envoyerNotification(
        destinataireId = vendeurId,
        type           = "PAIEMENT",
        titre          = "💳 Paiement reçu pour \"$articleTitre\"",
        corps          = "$acheteurNom a payé $montant F. L'argent est en séquestre jusqu'à confirmation.",
        deepLink       = "djassa://transaction/$transactionId"
    )

    /** Notifier le vendeur que l'article est marqué vendu et l'argent libéré */
    suspend fun notifierArticleVendu(
        vendeurId: String,
        montant: Int,
        articleTitre: String
    ) = envoyerNotification(
        destinataireId = vendeurId,
        type           = "ARTICLE_VENDU",
        titre          = "🎉 Article vendu !",
        corps          = "\"$articleTitre\" a été vendu. $montant F ont été ajoutés à votre portefeuille.",
        deepLink       = "djassa://profile/wallet"
    )

    /** Notifier le donateur que son don a été confirmé */
    suspend fun notifierDonConfirme(
        donateurId: String,
        beneficiaireNom: String,
        typeDon: String
    ) = envoyerNotification(
        destinataireId = donateurId,
        type           = "DON_CONFIRME",
        titre          = "🤝 Don confirmé !",
        corps          = "$beneficiaireNom a récupéré votre don : \"$typeDon\".",
        deepLink       = "djassa://dons/mes-dons"
    )

    /** Notifier l'utilisateur du résultat de sa certification */
    suspend fun notifierCertification(
        userId: String,
        approuve: Boolean
    ) = envoyerNotification(
        destinataireId = userId,
        type           = "CERTIFICATION",
        titre          = if (approuve) "✅ Compte certifié !" else "❌ Certification refusée",
        corps          = if (approuve)
            "Félicitations ! Votre badge de certification Djassa Eco est actif."
        else
            "Votre demande n'a pas pu être validée. Vérifiez vos informations et réessayez.",
        deepLink       = "djassa://parametres/certification"
    )

    // ═══════════════════════════════════════════════════════════════
    //  ENVOI INTERNE — passe par Firebase Function
    // ═══════════════════════════════════════════════════════════════

    private suspend fun envoyerNotification(
        destinataireId: String,
        type: String,
        titre: String,
        corps: String,
        deepLink: String
    ) {
        try {
            val data = hashMapOf(
                "destinataireId" to destinataireId,
                "type"           to type,
                "titre"          to titre,
                "corps"          to corps,
                "deepLink"       to deepLink
            )
            functions.getHttpsCallable("envoyerNotification").call(data).await()
        } catch (e: Exception) {
            Log.e("NotificationService", "Erreur envoi notification", e)
            // En cas d'échec serveur → sauvegarder quand même dans Firestore
            // pour que la notif apparaisse dans l'historique à la prochaine ouverture
            db.collection("notifications").add(
                hashMapOf(
                    "userId"    to destinataireId,
                    "type"      to type,
                    "titre"     to titre,
                    "corps"     to corps,
                    "deepLink"  to deepLink,
                    "lue"       to false,
                    "createdAt" to com.google.firebase.Timestamp.now()
                )
            )
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  TOKEN FCM — enregistrement à la connexion
    // ═══════════════════════════════════════════════════════════════

    suspend fun enregistrerToken(uid: String) {
        try {
            val token = com.google.firebase.messaging.FirebaseMessaging.getInstance()
                .token.await()
            db.collection("users").document(uid).update("fcmToken", token).await()
        } catch (e: Exception) {
            Log.e("NotificationService", "Erreur enregistrement token", e)
        }
    }
}