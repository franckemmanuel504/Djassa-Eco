package com.djassaeco.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.djassaeco.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

enum class NotifType(val channelId: String, val channelName: String) {
    MESSAGE         ("djassa_messages",      "Messages"),
    OFFRE           ("djassa_offres",        "Offres reçues"),
    OFFRE_ACCEPTEE  ("djassa_offres",        "Offres reçues"),
    PAIEMENT        ("djassa_paiements",     "Paiements"),
    LIVRAISON       ("djassa_livraisons",    "Livraisons"),
    CERTIFICATION   ("djassa_compte",        "Compte"),
    ARTICLE_VENDU   ("djassa_ventes",        "Mes ventes"),
    DON_CONFIRME    ("djassa_dons",          "Mes dons"),
    NOUVEAU_FAVORI  ("djassa_alertes",       "Alertes prix")
}

class DjassaFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(uid)
            .update("fcmToken", token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        val data    = message.data
        val titre   = message.notification?.title ?: data["titre"] ?: "DjassaEco"
        val corps   = message.notification?.body  ?: data["corps"] ?: ""
        val type    = data["type"] ?: "MESSAGE"
        val deepLink = data["deepLink"] ?: "" 

        afficherNotification(
            titre    = titre,
            corps    = corps,
            type     = NotifType.entries.find { it.name == type } ?: NotifType.MESSAGE,
            deepLink = deepLink
        )

        sauvegarderNotification(data)
    }

    private fun afficherNotification(titre: String, corps: String, type: NotifType, deepLink: String) {
        val notifManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        creerChannel(notifManager, type)

        val intent = if (deepLink.isNotEmpty()) {
            Intent(Intent.ACTION_VIEW, Uri.parse(deepLink)).apply {
                setPackage(packageName)
            }
        } else {
            packageManager.getLaunchIntentForPackage(packageName)
        }?.apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("notifType", type.name)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Correction : Utilisation de ic_launcher tant que les icônes personnalisées ne sont pas créées
        val icone = R.mipmap.ic_launcher

        val builder = NotificationCompat.Builder(this, type.channelId)
            .setSmallIcon(icone)
            .setContentTitle(titre)
            .setContentText(corps)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            .setContentIntent(pendingIntent)
            .setStyle(NotificationCompat.BigTextStyle().bigText(corps))

        notifManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }

    private fun creerChannel(manager: NotificationManager, type: NotifType) {
        if (manager.getNotificationChannel(type.channelId) != null) return
        val channel = NotificationChannel(type.channelId, type.channelName, NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Notifications ${type.channelName} DjassaEco"
            enableVibration(true)
        }
        manager.createNotificationChannel(channel)
    }

    private fun sauvegarderNotification(data: Map<String, String>) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val notif = hashMapOf(
            "userId"    to uid,
            "type"      to (data["type"] ?: "MESSAGE"),
            "titre"     to (data["titre"] ?: ""),
            "corps"     to (data["corps"] ?: ""),
            "deepLink"  to (data["deepLink"] ?: ""),
            "lue"       to false,
            "createdAt" to com.google.firebase.Timestamp.now()
        )
        FirebaseFirestore.getInstance().collection("notifications").add(notif)
    }
}
