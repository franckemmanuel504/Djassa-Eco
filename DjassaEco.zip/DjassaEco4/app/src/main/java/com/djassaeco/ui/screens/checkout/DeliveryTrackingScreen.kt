package com.djassaeco.ui.screens.checkout

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.djassaeco.ui.theme.*
import kotlinx.coroutines.delay
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

// ─── Étapes de livraison ─────────────────────────────────────────────────────

enum class DeliveryStep(val label: String, val icon: ImageVector, val description: String) {
    CONFIRMED  ("Confirmée",     Icons.Default.CheckCircle,  "Commande validée"),
    PICKED_UP  ("Pris en charge",Icons.Default.Inventory2,   "Livreur a récupéré l'article"),
    ON_THE_WAY ("En route",      Icons.Default.TwoWheeler,   "Votre livreur arrive bientôt"),
    DELIVERED  ("Livré !",       Icons.Default.Celebration,  "Colis remis avec succès")
}

// ════════════════════════════════════════════════════════════════════════════
//  ÉCRAN DE SUIVI EN TEMPS RÉEL
// ════════════════════════════════════════════════════════════════════════════
@Composable
fun DeliveryTrackingScreen(
    orderId: String,
    deliveryResult: DeliveryResult,
    sellerGeoPoint: GeoPoint = ABIDJAN_CENTER,
    onBack: () -> Unit,
    onContactRider: () -> Unit = {}
) {
    val context = LocalContext.current

    // ── Simulation progression (en prod → remplacer par Firestore listener) ──
    var currentStep      by remember { mutableStateOf(DeliveryStep.CONFIRMED) }
    var riderGeoPoint    by remember { mutableStateOf(sellerGeoPoint) }
    var remainingMinutes by remember { mutableIntStateOf(deliveryResult.estimatedMinutes) }
    var mapViewRef       by remember { mutableStateOf<MapView?>(null) }
    var riderMarkerRef   by remember { mutableStateOf<Marker?>(null) }

    LaunchedEffect(Unit) {
        delay(3_000)
        currentStep = DeliveryStep.PICKED_UP
        delay(3_000)
        currentStep = DeliveryStep.ON_THE_WAY

        val steps = 20
        val dLat  = (deliveryResult.geoPoint.latitude  - sellerGeoPoint.latitude)  / steps
        val dLon  = (deliveryResult.geoPoint.longitude - sellerGeoPoint.longitude) / steps
        repeat(steps) { i ->
            val newPoint = GeoPoint(
                sellerGeoPoint.latitude  + dLat * (i + 1),
                sellerGeoPoint.longitude + dLon * (i + 1)
            )
            riderGeoPoint    = newPoint
            remainingMinutes = (deliveryResult.estimatedMinutes * (steps - i - 1) / steps).coerceAtLeast(1)
            delay((deliveryResult.estimatedMinutes * 60_000L / steps).coerceIn(800L, 2_500L))
        }
        currentStep      = DeliveryStep.DELIVERED
        remainingMinutes = 0
    }

    // Mettre à jour le marqueur livreur quand sa position change
    LaunchedEffect(riderGeoPoint) {
        riderMarkerRef?.position = riderGeoPoint
        mapViewRef?.invalidate()
        if (currentStep == DeliveryStep.ON_THE_WAY) {
            mapViewRef?.controller?.animateTo(riderGeoPoint)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ── Carte osmdroid ────────────────────────────────────────────────────
        AndroidView(
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                    controller.setZoom(14.0)
                    controller.setCenter(
                        GeoPoint(
                            (sellerGeoPoint.latitude  + deliveryResult.geoPoint.latitude)  / 2,
                            (sellerGeoPoint.longitude + deliveryResult.geoPoint.longitude) / 2
                        )
                    )

                    // Ligne trajet (pointillée)
                    overlays.add(Polyline(this).apply {
                        setPoints(listOf(sellerGeoPoint, deliveryResult.geoPoint))
                        outlinePaint.color       = android.graphics.Color.parseColor("#1DB97A")
                        outlinePaint.strokeWidth = 7f
                        outlinePaint.alpha       = 120
                        outlinePaint.pathEffect  = android.graphics.DashPathEffect(
                            floatArrayOf(20f, 12f), 0f
                        )
                    })

                    // Marqueur vendeur (vert)
                    overlays.add(Marker(this).apply {
                        position = sellerGeoPoint
                        title    = "Vendeur"
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        icon = createColoredMarker(ctx, android.graphics.Color.parseColor("#1DB97A"))
                    })

                    // Marqueur destination (bleu)
                    overlays.add(Marker(this).apply {
                        position = deliveryResult.geoPoint
                        title    = "Votre adresse"
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        icon = createColoredMarker(ctx, android.graphics.Color.parseColor("#378ADD"))
                    })

                    // Marqueur livreur (orange — animé)
                    val riderMarker = Marker(this).apply {
                        position = sellerGeoPoint
                        title    = "Livreur"
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        icon = createColoredMarker(ctx, android.graphics.Color.parseColor("#E67E00"))
                    }
                    overlays.add(riderMarker)
                    riderMarkerRef = riderMarker
                    mapViewRef     = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // ── Bouton retour ─────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .padding(top = 16.dp, start = 16.dp)
                .statusBarsPadding()
                .size(44.dp)
                .shadow(6.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White)
                .align(Alignment.TopStart),
            contentAlignment = Alignment.Center
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
            }
        }

        // ── Panel bas ─────────────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .shadow(20.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color.White)
                .padding(20.dp)
                .navigationBarsPadding()
        ) {
            // Statut principal
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = {
                    fadeIn() + slideInVertically() togetherWith fadeOut() + slideOutVertically()
                },
                label = "step_anim"
            ) { step ->
                if (step == DeliveryStep.DELIVERED) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = EcoGreenLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.Celebration, null, tint = EcoGreen,
                                modifier = Modifier.size(28.dp))
                            Column {
                                Text("Livré avec succès ! 🎉",
                                    fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EcoGreen)
                                Text("Merci d'avoir choisi Djassa Eco",
                                    fontSize = 12.sp, color = EcoGreen.copy(alpha = 0.8f))
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(step.label, fontWeight = FontWeight.Bold,
                                fontSize = 16.sp, color = TextPrimary)
                            Text(step.description, fontSize = 12.sp, color = TextTertiary)
                        }
                        if (remainingMinutes > 0) EtaChip(remainingMinutes)
                        else PulsingDot()
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Stepper étapes
            DeliveryStepper(currentStep)

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = DividerColor)
            Spacer(Modifier.height(12.dp))

            // Info livreur
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier.size(44.dp).clip(CircleShape)
                        .background(AccentOrange.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, null, tint = AccentOrange,
                        modifier = Modifier.size(24.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Kouamé A.", fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp, color = TextPrimary)
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Star, null, tint = Color(0xFFFFB300),
                            modifier = Modifier.size(12.dp))
                        Text("4.8 · Livreur vérifié", fontSize = 11.sp, color = TextTertiary)
                    }
                }
                if (currentStep == DeliveryStep.ON_THE_WAY ||
                    currentStep == DeliveryStep.PICKED_UP) {
                    Surface(onClick = onContactRider, shape = CircleShape, color = EcoGreenLight) {
                        Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Phone, null, tint = EcoGreen,
                                modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(Modifier.width(4.dp))
                    Surface(onClick = {}, shape = CircleShape, color = Color(0xFFFFF8E6)) {
                        Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Chat, null, tint = AccentOrange,
                                modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            // Adresse destination
            Spacer(Modifier.height(10.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.LocationOn, null, tint = TextTertiary,
                    modifier = Modifier.size(14.dp))
                Text(deliveryResult.address, fontSize = 11.sp, color = TextTertiary,
                    modifier = Modifier.weight(1f))
            }
        }
    }
}

// ─── Composants réutilisables ────────────────────────────────────────────────

@Composable
fun EtaChip(minutes: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "eta")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "alpha"
    )
    Surface(shape = RoundedCornerShape(12.dp), color = EcoGreenLight) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(modifier = Modifier.size(7.dp).clip(CircleShape)
                .background(EcoGreen.copy(alpha = alpha)))
            Text("$minutes min", fontWeight = FontWeight.Bold,
                fontSize = 13.sp, color = EcoGreen)
        }
    }
}

@Composable
fun PulsingDot() {
    val infiniteTransition = rememberInfiniteTransition(label = "dot")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f, targetValue = 1.5f,
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
        label = "scale"
    )
    Box(
        modifier = Modifier.size((8 * scale).dp).clip(CircleShape).background(EcoGreen)
    )
}

@Composable
fun DeliveryStepper(currentStep: DeliveryStep) {
    val steps        = DeliveryStep.entries
    val currentIndex = steps.indexOf(currentStep)

    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        steps.forEachIndexed { index, step ->
            val isDone    = index <  currentIndex
            val isCurrent = index == currentIndex

            Box(
                modifier = Modifier
                    .size(if (isCurrent) 36.dp else 28.dp)
                    .clip(CircleShape)
                    .background(when {
                        isDone    -> EcoGreen
                        isCurrent -> EcoGreenLight
                        else      -> BackgroundLight
                    }),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isDone) Icons.Default.Check else step.icon,
                    contentDescription = null,
                    tint = when {
                        isDone    -> Color.White
                        isCurrent -> EcoGreen
                        else      -> TextTertiary
                    },
                    modifier = Modifier.size(if (isCurrent) 18.dp else 14.dp)
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier.weight(1f).height(2.dp)
                        .background(if (isDone) EcoGreen else DividerColor)
                )
            }
        }
    }

    Row(modifier = Modifier.fillMaxWidth()) {
        steps.forEachIndexed { index, step ->
            val isDone    = index <  currentIndex
            val isCurrent = index == currentIndex
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(4.dp))
                Text(
                    step.label.split(" ").first(),
                    fontSize = 9.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = when {
                        isDone    -> EcoGreen
                        isCurrent -> EcoGreen
                        else      -> TextTertiary
                    }
                )
            }
        }
    }
}
