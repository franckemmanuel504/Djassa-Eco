package com.djassaeco.ui.screens.checkout

import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.location.Geocoder
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.djassaeco.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.util.Locale

// ─── Modèles ─────────────────────────────────────────────────────────────────

data class DeliveryResult(
    val address: String,
    val geoPoint: GeoPoint,
    val distanceKm: Double,
    val estimatedMinutes: Int,
    val deliveryFee: Int,
    val mode: DeliveryMode
)

enum class DeliveryMode(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val baseColor: Color
) {
    STANDARD("Djassa Livraison", Icons.Default.LocalShipping, Color(0xFF378ADD)),
    EXPRESS("Express Moto",      Icons.Default.TwoWheeler,    Color(0xFFE67E00))
}

val ABIDJAN_CENTER = GeoPoint(5.3600, -4.0083)

fun haversineKm(a: GeoPoint, b: GeoPoint): Double {
    val R    = 6371.0
    val dLat = Math.toRadians(b.latitude  - a.latitude)
    val dLon = Math.toRadians(b.longitude - a.longitude)
    val s    = Math.sin(dLat / 2).let { it * it } +
               Math.cos(Math.toRadians(a.latitude)) *
               Math.cos(Math.toRadians(b.latitude)) *
               Math.sin(dLon / 2).let { it * it }
    return R * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s))
}

fun calculateDeliveryFee(distanceKm: Double, mode: DeliveryMode): Int = when (mode) {
    DeliveryMode.STANDARD -> when {
        distanceKm <= 5  -> 1000
        distanceKm <= 10 -> 1500
        distanceKm <= 20 -> 2000
        else             -> 2500
    }
    DeliveryMode.EXPRESS -> when {
        distanceKm <= 3  -> 1500
        distanceKm <= 7  -> 2000
        distanceKm <= 15 -> 2500
        else             -> 3000
    }
}

fun calculateEta(distanceKm: Double, mode: DeliveryMode): Int = when (mode) {
    DeliveryMode.STANDARD -> (distanceKm * 4 + 30).toInt().coerceAtLeast(30)
    DeliveryMode.EXPRESS  -> (distanceKm * 3 + 15).toInt().coerceAtLeast(15)
}

// ════════════════════════════════════════════════════════════════════════════
//  ÉCRAN : Choisir l'adresse de livraison
// ════════════════════════════════════════════════════════════════════════════
@Composable
fun DeliveryMapScreen(
    sellerGeoPoint: GeoPoint = ABIDJAN_CENTER,
    onBack: () -> Unit,
    onConfirm: (DeliveryResult) -> Unit
) {
    val context = LocalContext.current
    val scope   = rememberCoroutineScope()

    var selectedGeoPoint by remember { mutableStateOf<GeoPoint?>(null) }
    var selectedAddress  by remember { mutableStateOf("") }
    var searchQuery      by remember { mutableStateOf("") }
    var suggestions      by remember { mutableStateOf<List<String>>(emptyList()) }
    var isSearching      by remember { mutableStateOf(false) }
    var selectedMode     by remember { mutableStateOf(DeliveryMode.STANDARD) }
    var distanceKm       by remember { mutableDoubleStateOf(0.0) }
    var mapViewRef       by remember { mutableStateOf<MapView?>(null) }
    var pendingDeliveryResult by remember { mutableStateOf<DeliveryResult?>(null) }

    fun refreshPosition(point: GeoPoint) {
        selectedGeoPoint = point
        distanceKm = haversineKm(sellerGeoPoint, point)
        
        // Mise à jour de la ligne de trajet sur la carte
        mapViewRef?.let { mv ->
            // Nettoyage des anciennes lignes
            mv.overlays.removeAll { it is Polyline }
            
            val line = Polyline(mv).apply {
                addPoint(sellerGeoPoint)
                addPoint(point)
                outlinePaint.color = android.graphics.Color.parseColor("#1DB97A")
                outlinePaint.strokeWidth = 8f
                outlinePaint.strokeCap = Paint.Cap.ROUND
            }
            mv.overlays.add(line)
            mv.invalidate()
        }

        scope.launch {
            selectedAddress = reverseGeocode(point, context)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ── Carte osmdroid ────────────────────────────────────────────────────
        AndroidView(
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                    controller.setZoom(14.0)
                    controller.setCenter(ABIDJAN_CENTER)

                    // Overlay localisation utilisateur
                    val myLocation = MyLocationNewOverlay(GpsMyLocationProvider(ctx), this)
                    myLocation.enableMyLocation()
                    overlays.add(myLocation)

                    // Marqueur vendeur vert
                    overlays.add(Marker(this).apply {
                        position = sellerGeoPoint
                        title    = "Vendeur"
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        icon = createColoredMarker(ctx, android.graphics.Color.parseColor("#1DB97A"))
                    })

                    mapViewRef = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // ── Pin central fixe (style Yango) ────────────────────────────────────
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.offset(y = (-28).dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .background(EcoGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.LocationOn, null, tint = Color.White,
                        modifier = Modifier.size(24.dp))
                }
                Box(modifier = Modifier.width(2.dp).height(16.dp).background(EcoGreen))
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(EcoGreen))
            }
        }

        // ── Bouton "Confirmer cette position" (milieu bas du pin) ─────────────
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 40.dp)
        ) {
            Surface(
                onClick = {
                    mapViewRef?.let { mv ->
                        refreshPosition(mv.mapCenter as GeoPoint)
                    }
                },
                shape = RoundedCornerShape(20.dp),
                color = Color.White,
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Refresh, null, tint = EcoGreen,
                        modifier = Modifier.size(14.dp))
                    Text("Valider cette position", fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold, color = EcoGreen)
                }
            }
        }

        // ── Barre de recherche ────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, start = 16.dp, end = 16.dp)
                .statusBarsPadding()
        ) {
            Surface(shape = RoundedCornerShape(16.dp), shadowElevation = 8.dp, color = Color.White) {
                Row(
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                    }
                    TextField(
                        value = searchQuery,
                        onValueChange = { q ->
                            searchQuery = q
                            if (q.length >= 3) {
                                isSearching = true
                                scope.launch {
                                    suggestions = searchAbidjanAddresses(q, context)
                                    isSearching = false
                                }
                            } else suggestions = emptyList()
                        },
                        placeholder = {
                            Text("Chercher une adresse à Abidjan…", fontSize = 13.sp,
                                color = TextTertiary)
                        },
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor   = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor   = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true
                    )
                    if (isSearching) CircularProgressIndicator(
                        modifier = Modifier.size(20.dp).padding(end = 8.dp),
                        strokeWidth = 2.dp, color = EcoGreen
                    )
                }
            }

            // Suggestions d'adresses
            AnimatedVisibility(
                visible = suggestions.isNotEmpty(),
                enter   = fadeIn() + slideInVertically(),
                exit    = fadeOut() + slideOutVertically()
            ) {
                Surface(shape = RoundedCornerShape(12.dp), shadowElevation = 6.dp,
                    modifier = Modifier.padding(top = 4.dp)) {
                    LazyColumn {
                        items(suggestions.take(5)) { suggestion ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        searchQuery = suggestion
                                        suggestions = emptyList()
                                        scope.launch {
                                            val point = geocodeAddress(suggestion, context)
                                            point?.let {
                                                mapViewRef?.controller?.animateTo(it)
                                                mapViewRef?.controller?.setZoom(16.0)
                                                delay(900)
                                                refreshPosition(it)
                                            }
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Place, null, tint = EcoGreen,
                                    modifier = Modifier.size(18.dp))
                                Text(suggestion, fontSize = 13.sp, color = TextPrimary)
                            }
                            HorizontalDivider(color = DividerColor)
                        }
                    }
                }
            }
        }

        // ── Panel bas ─────────────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color.White)
                .padding(20.dp)
                .navigationBarsPadding()
        ) {
            Text("LIVRAISON À", fontSize = 10.sp, fontWeight = FontWeight.Bold,
                color = TextTertiary, letterSpacing = .8.sp)
            Spacer(Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier.size(36.dp).clip(CircleShape).background(EcoGreenLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.LocationOn, null, tint = EcoGreen,
                        modifier = Modifier.size(18.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        selectedAddress.ifBlank { "Déplace la carte → appuie sur \"Valider\"" },
                        fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextPrimary
                    )
                    if (distanceKm > 0) Text(
                        "~${String.format("%.1f", distanceKm)} km du vendeur",
                        fontSize = 11.sp, color = TextTertiary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = DividerColor)
            Spacer(Modifier.height(14.dp))

            Text("MODE DE LIVRAISON", fontSize = 10.sp, fontWeight = FontWeight.Bold,
                color = TextTertiary, letterSpacing = .8.sp)
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DeliveryMode.entries.forEach { mode ->
                    val fee      = calculateDeliveryFee(distanceKm, mode)
                    val eta      = calculateEta(distanceKm, mode)
                    val selected = selectedMode == mode
                    Surface(
                        onClick = { selectedMode = mode },
                        shape   = RoundedCornerShape(14.dp),
                        color   = if (selected) EcoGreenLight else BackgroundLight,
                        border  = if (selected)
                            androidx.compose.foundation.BorderStroke(1.5.dp, EcoGreen)
                        else
                            androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(mode.icon, null,
                                    tint = if (selected) EcoGreen else mode.baseColor,
                                    modifier = Modifier.size(16.dp))
                                Text(mode.label, fontWeight = FontWeight.SemiBold, fontSize = 10.sp,
                                    color = if (selected) EcoGreen else TextPrimary)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text("$fee F CFA", fontWeight = FontWeight.Bold, fontSize = 14.sp,
                                color = if (selected) EcoGreen else TextPrimary)
                            Text("~$eta min", fontSize = 10.sp, color = TextTertiary)
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Button(
                onClick = {
                    selectedGeoPoint?.let { point ->
                        pendingDeliveryResult = DeliveryResult(
                            address          = selectedAddress,
                            geoPoint         = point,
                            distanceKm       = distanceKm,
                            estimatedMinutes = calculateEta(distanceKm, selectedMode),
                            deliveryFee      = calculateDeliveryFee(distanceKm, selectedMode),
                            mode             = selectedMode
                        )
                    }
                },
                enabled  = selectedAddress.isNotBlank() && selectedGeoPoint != null,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape    = RoundedCornerShape(14.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = EcoGreen)
            ) {
                Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Confirmer cette adresse", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }

        // ── Dialogue de confirmation finale ───────────────────────────────────
        pendingDeliveryResult?.let { result ->
            AlertDialog(
                onDismissRequest = { pendingDeliveryResult = null },
                title = { Text("Confirmer la livraison", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Voulez-vous confirmer la livraison à cette adresse ?", fontSize = 14.sp)
                        Surface(
                            color = BackgroundLight,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(result.address, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Mode : ${result.mode.label}", fontSize = 12.sp, color = TextTertiary)
                                Text("Frais : ${result.deliveryFee} F CFA", fontWeight = FontWeight.Bold, color = EcoGreen)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onConfirm(result)
                            pendingDeliveryResult = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EcoGreen)
                    ) {
                        Text("Confirmer")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDeliveryResult = null }) {
                        Text("Modifier", color = TextTertiary)
                    }
                },
                shape = RoundedCornerShape(20.dp),
                containerColor = Color.White
            )
        }
    }
}

// ─── Utilitaires ─────────────────────────────────────────────────────────────

suspend fun reverseGeocode(point: GeoPoint, context: Context): String =
    withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale.FRENCH)
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(point.latitude, point.longitude, 1)
            if (addresses?.isNotEmpty() == true) {
                val addr = addresses[0]
                val street = addr.thoroughfare ?: ""
                val feature = addr.featureName ?: ""
                val locality = addr.locality ?: ""
                if (street.isNotBlank()) "$street, $locality"
                else if (feature.isNotBlank()) "$feature, $locality"
                else addr.getAddressLine(0) ?: "Adresse inconnue"
            } else "Adresse inconnue"
        } catch (e: Exception) {
            "Erreur de localisation"
        }
    }

suspend fun searchAbidjanAddresses(query: String, context: Context): List<String> =
    withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale.FRENCH)
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocationName("$query, Abidjan, Côte d'Ivoire", 5)
            addresses?.mapNotNull { it.getAddressLine(0) } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

suspend fun geocodeAddress(address: String, context: Context): GeoPoint? =
    withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale.FRENCH)
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocationName(address, 1)
            if (addresses?.isNotEmpty() == true) {
                GeoPoint(addresses[0].latitude, addresses[0].longitude)
            } else null
        } catch (e: Exception) {
            null
        }
    }

fun createColoredMarker(context: Context, color: Int): BitmapDrawable {
    val size = 120
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint().apply {
        isAntiAlias = true
        this.color = color
    }
    
    canvas.drawCircle(size / 2f, size / 3f, size / 3f, paint)
    val path = Path().apply {
        moveTo(size / 6f, size / 3f)
        lineTo(size / 2f, size * 0.9f)
        lineTo(size * 5 / 6f, size / 3f)
        close()
    }
    canvas.drawPath(path, paint)
    
    paint.color = android.graphics.Color.WHITE
    canvas.drawCircle(size / 2f, size / 3f, size / 8f, paint)

    return BitmapDrawable(context.resources, bitmap)
}
