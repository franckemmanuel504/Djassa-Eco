package com.djassaeco.ui.screens.dons

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djassaeco.data.model.Don
import com.djassaeco.ui.theme.*

@Composable
fun DonsScreen(
    dons: List<Don>,
    onDonParticulier: () -> Unit,
    onDonAssociation: () -> Unit,
    onVoirTout: () -> Unit,
    onContactDonneur: (Don) -> Unit
) {
    // On ne garde que les dons destinés aux particuliers pour cette section (dons entre voisins)
    val donsParticuliers = remember(dons) {
        dons.filter { it.typeDestinataire == "PARTICULIER" }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        // Header
        Surface(color = Color.White) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                Text("Faire un don", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
                Text("Chaque geste compte pour notre planète", fontSize = 11.sp, color = TextTertiary, modifier = Modifier.padding(top = 3.dp))
            }
            HorizontalDivider(color = DividerColor)
        }

        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            Box(
                modifier = Modifier.size(100.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xFFE8F8F1)),
                contentAlignment = Alignment.Center
            ) {
                Text("♻️", fontSize = 42.sp)
            }

            Spacer(Modifier.height(20.dp))
            Text("Choisissez votre impact", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
            Spacer(Modifier.height(8.dp))
            Text(
                "Donnez à un voisin ou soutenez une cause.",
                fontSize = 13.sp, color = TextTertiary, textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(24.dp))

            // --- SECTION CHOIX ---
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                DonOptionCard(
                    title = "À un particulier",
                    description = "Donne à quelqu'un dans le besoin autour de toi.",
                    icon = Icons.Default.People,
                    backgroundColor = Color(0xFFF0FDF8),
                    accentColor = EcoGreen,
                    onClick = onDonParticulier
                )

                Spacer(Modifier.height(14.dp))

                DonOptionCard(
                    title = "À une association",
                    description = "Soutiens orphelinats et banques alimentaires.",
                    icon = Icons.Default.AccountBalance,
                    backgroundColor = Color(0xFFE8F2FF),
                    accentColor = AccentBlue,
                    onClick = onDonAssociation
                )
            }

            Spacer(Modifier.height(32.dp))

            // --- SECTION : DONS ENTRE PARTICULIERS DISPONIBLES ---
            if (donsParticuliers.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Dons disponibles", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                    Text(
                        "Voir tout", 
                        fontSize = 12.sp, 
                        color = EcoGreen, 
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { onVoirTout() }
                    )
                }

                Spacer(Modifier.height(14.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(donsParticuliers) { don ->
                        DonneurCard(don = don, onClick = { onContactDonneur(don) })
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
            
            // Badges
            Row(modifier = Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EcoBadge(Icons.Default.Shield, "Dons vérifiés")
                EcoBadge(Icons.Default.Favorite, "100% Solidaire")
            }
            
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun DonneurCard(don: Don, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFEEEEEE)),
        shadowElevation = 2.dp,
        modifier = Modifier.width(150.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).background(EcoGreen.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(don.donateur?.take(1) ?: "D", fontWeight = FontWeight.Bold, color = EcoGreen)
            }
            Spacer(Modifier.height(8.dp))
            Text(don.donateur ?: "Donneur", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary, maxLines = 1)
            Text(don.typeDon, fontSize = 11.sp, color = EcoGreen, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(10.dp), tint = TextTertiary)
                Text(don.localisation, fontSize = 10.sp, color = TextTertiary)
            }
            Spacer(Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = EcoGreen,
                modifier = Modifier.fillMaxWidth().height(26.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("Récupérer", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DonOptionCard(title: String, description: String, icon: ImageVector, backgroundColor: Color, accentColor: Color, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(20.dp), color = backgroundColor, border = BorderStroke(1.dp, accentColor.copy(alpha = 0.2f))) {
        Row(modifier = Modifier.padding(18.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(modifier = Modifier.size(50.dp).background(Color.White, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(24.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Text(description, fontSize = 11.sp, color = TextSecondary, lineHeight = 16.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = accentColor.copy(alpha = 0.5f))
        }
    }
}

@Composable
fun EcoBadge(icon: ImageVector, label: String) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFF4F4F4)) {
        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(icon, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(12.dp))
            Text(label, fontSize = 10.sp, color = TextTertiary, fontWeight = FontWeight.SemiBold)
        }
    }
}
